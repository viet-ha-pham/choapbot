from __future__ import annotations

import numpy as np
from sentence_transformers import SentenceTransformer
from .models import ArticleChunk


class Embedder:
    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)

    def encode_chunks(self, chunks: list[ArticleChunk], batch_size: int = 64) -> np.ndarray:
        texts = [c.representative_text for c in chunks]
        emb = self.model.encode(texts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=True)
        return np.asarray(emb, dtype="float32")
