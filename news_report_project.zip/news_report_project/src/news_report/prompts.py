from __future__ import annotations

from .models import NewsArticle, OntologyTopic

SYSTEM_REPORTER = """Bạn là biên tập viên báo cáo tổng hợp thông tin báo chí.
Yêu cầu chung:
- Văn phong trang trọng, ngắn gọn, phù hợp báo cáo.
- Không bịa số liệu, thời gian, kết quả, nguồn phát ngôn.
- Luôn nêu rõ sự kiện/chủ thể/hành động/thời gian/tình hình/kết quả/số liệu nếu có trong bài.
- Nếu thiếu dữ kiện thì ghi ở mức thận trọng, không tự suy diễn.
- Câu có thông tin quan trọng nên kèm nguồn domain trong ngoặc.
- Loại bỏ thông tin cũ, quảng cáo, bình luận lan man, nội dung không liên quan đề mục.
Trả về JSON hợp lệ, không markdown.
"""


def ontology_text(ontology: list[OntologyTopic]) -> str:
    return "\n".join(
        f"- {t.id} | {t.label}: {t.description} Include={t.include_rules} Exclude={t.exclude_rules}"
        for t in ontology
    )


def classify_hot_prompt(article: NewsArticle, ontology: list[OntologyTopic]) -> str:
    return f"""Phân loại bài báo vào đúng một đề mục ontology.

ONTOLOGY:
{ontology_text(ontology)}

BÀI BÁO:
Title: {article.title}
Domain: {article.domain}
Content: {article.content[:6000]}

JSON schema:
{{"topic_id":"...", "topic_label":"...", "reason":"..."}}
"""


def summarize_hot_prompt(article: NewsArticle, topic_label: str) -> str:
    return f"""Tóm tắt bài HOT cho đề mục: {topic_label}.

Tiêu chí bắt buộc:
1. Rõ sự kiện chính, chủ thể hành động, thời gian/ngày giờ nếu có.
2. Rõ tình hình, kết quả, yêu cầu/nhiệm vụ, số liệu cụ thể nếu bài có.
3. Nêu nguồn domain trong câu hoặc cuối câu.
4. Không quá 140 từ.
5. Văn phong báo cáo, không giật tít.

BÀI BÁO:
Title: {article.title}
Domain: {article.domain}
Content: {article.content[:8000]}

JSON schema:
{{"summary":"..."}}
"""


def check_hot_prompt(summary: str, article: NewsArticle, topic_label: str) -> str:
    return f"""Kiểm tra tóm tắt bài HOT.

Đề mục: {topic_label}
Tóm tắt: {summary}
Nguồn gốc:
Title: {article.title}
Domain: {article.domain}
Content: {article.content[:6000]}

Chấm các lỗi:
- thiếu nguồn domain
- thiếu thời gian nếu bài có
- thiếu chủ thể/sự kiện/kết quả/số liệu quan trọng
- bịa hoặc suy diễn
- văn phong không phù hợp báo cáo

JSON schema:
{{"quality":"pass|fail", "issues":["..."], "repair_instruction":"..."}}
"""


def refine_hot_prompt(summary: str, issues: list[str], article: NewsArticle, topic_label: str) -> str:
    return f"""Sửa tóm tắt bài HOT theo lỗi đã phát hiện.
Đề mục: {topic_label}
Bản cũ: {summary}
Lỗi: {issues}
Bài gốc: Title={article.title}; Domain={article.domain}; Content={article.content[:8000]}

JSON schema:
{{"summary":"..."}}
"""


def summarize_cluster_prompt(articles: list[NewsArticle], ontology: list[OntologyTopic]) -> str:
    items = []
    for a in articles:
        items.append(f"[DOC {a.doc_id}] Title: {a.title}\nDomain: {a.domain}\nContent: {a.content[:2500]}")
    return f"""Tóm tắt cụm bài KHÔNG HOT ở mức đại thể, ngắn gọn.

Nhiệm vụ:
- Chỉ giữ nội dung liên quan các đề mục báo cáo trong ontology.
- Tự chọn đúng một đề mục phù hợp nhất; nếu không liên quan, trả topic_id = "bo_qua".
- Tổng hợp đại ý, không cần chi tiết như bài hot, nhưng không được bịa.
- Có thể nêu một vài domain tiêu biểu.
- Không quá 120 từ.

ONTOLOGY:
{ontology_text(ontology)}

CỤM BÀI:
{chr(10).join(items)}

JSON schema:
{{"topic_id":"...", "topic_label":"...", "summary":"...", "source_domains":["..."]}}
"""


def check_cluster_prompt(summary: str, articles: list[NewsArticle], ontology: list[OntologyTopic]) -> str:
    titles = "\n".join(f"- {a.title} ({a.domain})" for a in articles)
    return f"""Kiểm tra tóm tắt cụm không hot.

Tóm tắt: {summary}
Các bài trong cụm:
{titles}

Tiêu chí:
- đúng đề mục ontology hoặc bỏ qua nếu không liên quan
- ngắn gọn, đại thể, không sa vào bài riêng lẻ
- không bịa số liệu/kết quả
- văn phong báo cáo

JSON schema:
{{"quality":"pass|fail", "issues":["..."], "repair_instruction":"..."}}
"""


def refine_cluster_prompt(summary: str, issues: list[str], articles: list[NewsArticle], ontology: list[OntologyTopic]) -> str:
    return f"""Sửa tóm tắt cụm theo lỗi.
Bản cũ: {summary}
Lỗi: {issues}

{summarize_cluster_prompt(articles, ontology)}
"""
