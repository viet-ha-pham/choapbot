from __future__ import annotations

from .models import ArticleChunk, NewsArticle, PipelineConfig
from .utils import estimate_tokens, normalize_text, split_paragraphs


def _simhash(text: str, bits: int = 64) -> int:
    import hashlib
    weights = [0] * bits
    for token in normalize_text(text).split():
        hv = int(hashlib.md5(token.encode("utf-8")).hexdigest(), 16)
        for i in range(bits):
            weights[i] += 1 if (hv >> i) & 1 else -1
    out = 0
    for i, w in enumerate(weights):
        if w >= 0:
            out |= 1 << i
    return out


def _hamming(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def deduplicate(articles: list[NewsArticle], cfg: PipelineConfig) -> list[NewsArticle]:
    exact_seen: set[str] = set()
    hashes: list[int] = []
    kept: list[NewsArticle] = []
    for a in articles:
        key = normalize_text(a.title + " " + a.content)
        if key in exact_seen:
            continue
        sh = _simhash(key)
        if any(_hamming(sh, old) <= cfg.duplicate_simhash_hamming_threshold for old in hashes):
            continue
        exact_seen.add(key)
        hashes.append(sh)
        kept.append(a)
    return kept


def filter_noise(articles: list[NewsArticle], cfg: PipelineConfig) -> list[NewsArticle]:
    nd = {d.lower() for d in cfg.noise_domains}
    title_kw = [k.lower() for k in cfg.noise_title_keywords]
    content_kw = [k.lower() for k in cfg.noise_content_keywords]
    out = []
    for a in articles:
        title = a.title.lower()
        content = a.content.lower()
        domain = a.domain.lower()
        if len(a.content) < cfg.min_content_chars:
            continue
        if domain in nd or any(domain.endswith("." + d) for d in nd):
            continue
        if any(k in title for k in title_kw):
            continue
        if any(k in content for k in content_kw):
            continue
        out.append(a)
    return out


def make_representative_chunk(article: NewsArticle) -> ArticleChunk:
    paras = split_paragraphs(article.content)
    lead = " ".join(paras[:2])
    tail = " ".join(paras[-2:]) if len(paras) > 2 else ""
    text = f"TIÊU ĐỀ: {article.title}\nLEAD: {lead}\nĐOẠN CUỐI: {tail}".strip()
    return ArticleChunk(doc_id=article.doc_id, representative_text=text, token_estimate=estimate_tokens(text))
