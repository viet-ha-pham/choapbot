from __future__ import annotations

import argparse
import asyncio
from pathlib import Path
from .pipeline.runner import run_pipeline


def main() -> None:
    parser = argparse.ArgumentParser(prog="news-report")
    sub = parser.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run")
    run.add_argument("input_jsonl", type=Path)
    run.add_argument("--config", type=Path, default=Path("config/default.yaml"))
    run.add_argument("--out-dir", type=Path, default=Path("outputs"))
    args = parser.parse_args()

    if args.cmd == "run":
        output = asyncio.run(run_pipeline(args.input_jsonl, args.config, args.out_dir))
        print(f"Wrote: {output}")


if __name__ == "__main__":
    main()
