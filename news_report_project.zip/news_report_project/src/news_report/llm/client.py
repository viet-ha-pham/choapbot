from __future__ import annotations

import json
from typing import Any
from openai import AsyncOpenAI


class JsonLLM:
    def __init__(self, model: str, temperature: float = 0.1):
        self.client = AsyncOpenAI()
        self.model = model
        self.temperature = temperature

    async def complete_json(self, system: str, user: str) -> dict[str, Any]:
        resp = await self.client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        text = resp.choices[0].message.content or "{}"
        return json.loads(text)
