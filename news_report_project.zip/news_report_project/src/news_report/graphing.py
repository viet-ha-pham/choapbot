from __future__ import annotations

import faiss
import networkx as nx
import numpy as np
from .models import ArticleChunk, PipelineConfig


def build_faiss_index(embeddings: np.ndarray) -> faiss.Index:
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings.astype("float32"))
    return index


def build_similarity_graph(chunks: list[ArticleChunk], embeddings: np.ndarray, cfg: PipelineConfig) -> nx.Graph:
    index = build_faiss_index(embeddings)
    k = min(cfg.faiss_k + 1, len(chunks))
    scores, idxs = index.search(embeddings.astype("float32"), k)
    g = nx.Graph()
    for i, c in enumerate(chunks):
        g.add_node(c.doc_id, pos=i, token_estimate=c.token_estimate)
    for i in range(len(chunks)):
        src = chunks[i].doc_id
        for score, j in zip(scores[i], idxs[i]):
            if j < 0 or j == i:
                continue
            if float(score) >= cfg.similarity_threshold:
                dst = chunks[int(j)].doc_id
                if g.has_edge(src, dst):
                    if score > g[src][dst]["weight"]:
                        g[src][dst]["weight"] = float(score)
                else:
                    g.add_edge(src, dst, weight=float(score))
    return g


def select_hot_doc_ids(g: nx.Graph, top_n: int) -> set[str]:
    if g.number_of_nodes() == 0:
        return set()
    pr = nx.pagerank(g, weight="weight")
    return {doc_id for doc_id, _ in sorted(pr.items(), key=lambda kv: kv[1], reverse=True)[:top_n]}
