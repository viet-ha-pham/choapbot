from __future__ import annotations

from collections import defaultdict
import igraph as ig
import leidenalg
import networkx as nx

from .models import ArticleChunk, PipelineConfig


def _induced_igraph(g: nx.Graph, nodes: list[str]) -> ig.Graph:
    sub = g.subgraph(nodes).copy()
    mapping = {n: i for i, n in enumerate(sub.nodes())}
    edges = [(mapping[u], mapping[v]) for u, v in sub.edges()]
    weights = [sub[u][v].get("weight", 1.0) for u, v in sub.edges()]
    out = ig.Graph(n=len(mapping), edges=edges, directed=False)
    out.vs["name"] = list(mapping.keys())
    if weights:
        out.es["weight"] = weights
    return out


def _token_sum(nodes: list[str], token_by_doc: dict[str, int]) -> int:
    return sum(token_by_doc.get(n, 0) for n in nodes)


def _leiden_once(g: nx.Graph, nodes: list[str], cfg: PipelineConfig) -> list[list[str]]:
    if len(nodes) <= 1:
        return [nodes]
    igg = _induced_igraph(g, nodes)
    if igg.ecount() == 0:
        return [[n] for n in nodes]
    part = leidenalg.find_partition(
        igg,
        leidenalg.RBConfigurationVertexPartition,
        weights="weight" if igg.ecount() else None,
        resolution_parameter=cfg.leiden_resolution,
    )
    clusters = []
    names = igg.vs["name"]
    for comm in part:
        clusters.append([names[i] for i in comm])
    return clusters


def recursive_leiden(g: nx.Graph, nodes: list[str], token_by_doc: dict[str, int], cfg: PipelineConfig, depth: int = 0) -> list[list[str]]:
    total = _token_sum(nodes, token_by_doc)
    if total <= cfg.max_cluster_tokens or depth >= cfg.max_recursion_depth or len(nodes) <= 1:
        return [nodes]
    clusters = _leiden_once(g, nodes, cfg)
    if len(clusters) == 1:
        return [nodes]
    out: list[list[str]] = []
    for c in clusters:
        out.extend(recursive_leiden(g, c, token_by_doc, cfg, depth + 1))
    return out


def refine_clusters(clusters: list[list[str]], token_by_doc: dict[str, int], cfg: PipelineConfig) -> list[list[str]]:
    # 1) split cluster quá to bằng greedy token chunks nếu Leiden không chia được nữa.
    split: list[list[str]] = []
    for c in clusters:
        bucket: list[str] = []
        cur = 0
        for doc_id in sorted(c, key=lambda d: token_by_doc.get(d, 0), reverse=True):
            t = token_by_doc.get(doc_id, 0)
            if bucket and cur + t > cfg.max_cluster_tokens:
                split.append(bucket)
                bucket, cur = [], 0
            bucket.append(doc_id)
            cur += t
        if bucket:
            split.append(bucket)

    # 2) merge cluster quá nhỏ vào nhau để tiết kiệm LLM.
    refined: list[list[str]] = []
    small: list[str] = []
    small_tokens = 0
    for c in split:
        t = _token_sum(c, token_by_doc)
        if t < cfg.min_cluster_tokens:
            small.extend(c)
            small_tokens += t
            if small_tokens >= cfg.min_cluster_tokens:
                refined.append(small)
                small, small_tokens = [], 0
        else:
            refined.append(c)
    if small:
        if refined and _token_sum(refined[-1], token_by_doc) + small_tokens <= cfg.max_cluster_tokens:
            refined[-1].extend(small)
        else:
            refined.append(small)
    return refined
