from __future__ import annotations

from pathlib import Path
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

from ..models import ReportSection


def write_docx(sections: list[ReportSection], output_path: Path, title: str) -> None:
    doc = Document()
    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(11)

    h = doc.add_heading(title, level=0)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph("Báo cáo tổng hợp tự động từ nguồn báo chí, chia theo đề mục; bài nổi bật được trình bày trước, sau đó là tổng hợp đại thể các cụm còn lại.")

    for sec in sections:
        doc.add_heading(sec.topic_label, level=1)
        if sec.hot:
            doc.add_heading("Tin nổi bật", level=2)
            for item in sec.hot:
                p = doc.add_paragraph(style=None)
                p.style = doc.styles["List Bullet"]
                p.add_run(item.summary).bold = False
                p.add_run(f" Nguồn: {item.source_domain}.").italic = True
        if sec.general:
            doc.add_heading("Tổng hợp đại thể", level=2)
            for item in sec.general:
                p = doc.add_paragraph(style=None)
                p.style = doc.styles["List Bullet"]
                p.add_run(item.summary)
                if item.source_domains:
                    p.add_run(f" Nguồn tiêu biểu: {', '.join(item.source_domains[:5])}.").italic = True
        if not sec.hot and not sec.general:
            doc.add_paragraph("Không có nội dung phù hợp.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)
