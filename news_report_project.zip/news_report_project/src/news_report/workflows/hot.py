from __future__ import annotations

from typing import TypedDict
from langgraph.graph import END, StateGraph

from ..llm.client import JsonLLM
from ..models import HotSummary, NewsArticle, PipelineConfig, SummaryQuality
from ..prompts import (
    SYSTEM_REPORTER,
    check_hot_prompt,
    classify_hot_prompt,
    refine_hot_prompt,
    summarize_hot_prompt,
)


class HotState(TypedDict, total=False):
    article: NewsArticle
    topic_id: str
    topic_label: str
    summary: str
    quality: str
    issues: list[str]
    attempts: int


def build_hot_workflow(llm: JsonLLM, cfg: PipelineConfig):
    async def classify(state: HotState) -> HotState:
        data = await llm.complete_json(SYSTEM_REPORTER, classify_hot_prompt(state["article"], cfg.ontology))
        state["topic_id"] = data.get("topic_id", "khac")
        state["topic_label"] = data.get("topic_label", state["topic_id"])
        return state

    async def summarize(state: HotState) -> HotState:
        data = await llm.complete_json(SYSTEM_REPORTER, summarize_hot_prompt(state["article"], state["topic_label"]))
        state["summary"] = data.get("summary", "")
        state["attempts"] = 0
        return state

    async def check(state: HotState) -> HotState:
        data = await llm.complete_json(SYSTEM_REPORTER, check_hot_prompt(state["summary"], state["article"], state["topic_label"]))
        state["quality"] = data.get("quality", "fail")
        state["issues"] = data.get("issues", [])
        return state

    async def refine(state: HotState) -> HotState:
        data = await llm.complete_json(SYSTEM_REPORTER, refine_hot_prompt(state["summary"], state.get("issues", []), state["article"], state["topic_label"]))
        state["summary"] = data.get("summary", state["summary"])
        state["attempts"] = state.get("attempts", 0) + 1
        return state

    def route_after_check(state: HotState) -> str:
        if state.get("quality") == "pass" or state.get("attempts", 0) >= 1:
            return END
        return "refine"

    graph = StateGraph(HotState)
    graph.add_node("classify", classify)
    graph.add_node("summarize", summarize)
    graph.add_node("check", check)
    graph.add_node("refine", refine)
    graph.set_entry_point("classify")
    graph.add_edge("classify", "summarize")
    graph.add_edge("summarize", "check")
    graph.add_conditional_edges("check", route_after_check)
    graph.add_edge("refine", "check")
    return graph.compile()


async def run_hot_article(article: NewsArticle, llm: JsonLLM, cfg: PipelineConfig) -> HotSummary:
    app = build_hot_workflow(llm, cfg)
    state = await app.ainvoke({"article": article})
    return HotSummary(
        doc_id=article.doc_id,
        topic_id=state.get("topic_id", "khac"),
        topic_label=state.get("topic_label", "Khác"),
        summary=state.get("summary", ""),
        source_domain=article.domain,
        quality=SummaryQuality.pass_ if state.get("quality") == "pass" else SummaryQuality.fail,
        issues=state.get("issues", []),
    )
