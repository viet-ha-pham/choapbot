from __future__ import annotations

from typing import TypedDict
from langgraph.graph import END, StateGraph

from ..llm.client import JsonLLM
from ..models import ClusterSummary, NewsArticle, PipelineConfig, SummaryQuality
from ..prompts import SYSTEM_REPORTER, check_cluster_prompt, refine_cluster_prompt, summarize_cluster_prompt


class ClusterState(TypedDict, total=False):
    cluster_id: str
    articles: list[NewsArticle]
    topic_id: str
    topic_label: str
    summary: str
    source_domains: list[str]
    quality: str
    issues: list[str]
    attempts: int


def build_cluster_workflow(llm: JsonLLM, cfg: PipelineConfig):
    async def summarize(state: ClusterState) -> ClusterState:
        data = await llm.complete_json(SYSTEM_REPORTER, summarize_cluster_prompt(state["articles"], cfg.ontology))
        state["topic_id"] = data.get("topic_id", "bo_qua")
        state["topic_label"] = data.get("topic_label", state["topic_id"])
        state["summary"] = data.get("summary", "")
        state["source_domains"] = data.get("source_domains", [])
        state["attempts"] = 0
        return state

    async def check(state: ClusterState) -> ClusterState:
        data = await llm.complete_json(SYSTEM_REPORTER, check_cluster_prompt(state["summary"], state["articles"], cfg.ontology))
        state["quality"] = data.get("quality", "fail")
        state["issues"] = data.get("issues", [])
        return state

    async def refine(state: ClusterState) -> ClusterState:
        data = await llm.complete_json(SYSTEM_REPORTER, refine_cluster_prompt(state["summary"], state.get("issues", []), state["articles"], cfg.ontology))
        state["topic_id"] = data.get("topic_id", state.get("topic_id", "bo_qua"))
        state["topic_label"] = data.get("topic_label", state.get("topic_label", "Bỏ qua"))
        state["summary"] = data.get("summary", state["summary"])
        state["source_domains"] = data.get("source_domains", state.get("source_domains", []))
        state["attempts"] = state.get("attempts", 0) + 1
        return state

    def route_after_check(state: ClusterState) -> str:
        if state.get("quality") == "pass" or state.get("attempts", 0) >= 1:
            return END
        return "refine"

    graph = StateGraph(ClusterState)
    graph.add_node("summarize", summarize)
    graph.add_node("check", check)
    graph.add_node("refine", refine)
    graph.set_entry_point("summarize")
    graph.add_edge("summarize", "check")
    graph.add_conditional_edges("check", route_after_check)
    graph.add_edge("refine", "check")
    return graph.compile()


async def run_cluster(cluster_id: str, articles: list[NewsArticle], llm: JsonLLM, cfg: PipelineConfig) -> ClusterSummary | None:
    app = build_cluster_workflow(llm, cfg)
    state = await app.ainvoke({"cluster_id": cluster_id, "articles": articles})
    if state.get("topic_id") == "bo_qua":
        return None
    return ClusterSummary(
        cluster_id=cluster_id,
        topic_id=state.get("topic_id", "khac"),
        topic_label=state.get("topic_label", "Khác"),
        summary=state.get("summary", ""),
        source_domains=state.get("source_domains", sorted({a.domain for a in articles})),
        doc_ids=[a.doc_id for a in articles],
        quality=SummaryQuality.pass_ if state.get("quality") == "pass" else SummaryQuality.fail,
        issues=state.get("issues", []),
    )
