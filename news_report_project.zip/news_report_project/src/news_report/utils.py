from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Iterable


def normalize_text(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w\sÀ-ỹ]", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()


def stable_id(*parts: str) -> str:
    h = hashlib.sha1()
    for p in parts:
        h.update((p or "").encode("utf-8", errors="ignore"))
        h.update(b"\0")
    return h.hexdigest()[:16]


def estimate_tokens(text: str) -> int:
    # Ước lượng thô cho tiếng Việt: khoảng 1 token ~= 0.75 từ.
    return max(1, int(len(text.split()) / 0.75))


def iter_jsonl(path: Path) -> Iterable[dict]:
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSONL at line {line_no}: {e}") from e


def split_paragraphs(text: str) -> list[str]:
    paras = [p.strip() for p in re.split(r"\n+", text or "") if p.strip()]
    if len(paras) <= 1:
        paras = [p.strip() for p in re.split(r"(?<=[.!?。])\s+", text or "") if p.strip()]
    return paras
