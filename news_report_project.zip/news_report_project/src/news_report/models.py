from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any
from pydantic import BaseModel, Field, field_validator


class NewsArticle(BaseModel):
    doc_id: str
    title: str
    content: str
    domain: str

    @field_validator("title", "content", "domain")
    @classmethod
    def non_empty(cls, v: str) -> str:
        return (v or "").strip()


class ArticleChunk(BaseModel):
    doc_id: str
    representative_text: str
    token_estimate: int


class OntologyTopic(BaseModel):
    id: str
    label: str
    description: str
    include_rules: list[str] = Field(default_factory=list)
    exclude_rules: list[str] = Field(default_factory=list)


class PipelineConfig(BaseModel):
    embedding_model: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
    duplicate_simhash_hamming_threshold: int = 3
    min_content_chars: int = 120
    faiss_k: int = 15
    similarity_threshold: float = 0.42
    hot_top_n: int = 10
    leiden_resolution: float = 1.0
    max_cluster_tokens: int = 6000
    min_cluster_tokens: int = 900
    max_recursion_depth: int = 4
    llm_model: str = "gpt-4.1-mini"
    llm_temperature: float = 0.1
    max_parallel_llm_tasks: int = 8
    noise_domains: list[str] = Field(default_factory=list)
    noise_title_keywords: list[str] = Field(default_factory=list)
    noise_content_keywords: list[str] = Field(default_factory=list)
    ontology: list[OntologyTopic] = Field(default_factory=list)


class SummaryQuality(str, Enum):
    pass_ = "pass"
    fail = "fail"


class HotSummary(BaseModel):
    doc_id: str
    topic_id: str
    topic_label: str
    summary: str
    source_domain: str
    quality: SummaryQuality = SummaryQuality.pass_
    issues: list[str] = Field(default_factory=list)


class ClusterSummary(BaseModel):
    cluster_id: str
    topic_id: str
    topic_label: str
    summary: str
    source_domains: list[str] = Field(default_factory=list)
    doc_ids: list[str] = Field(default_factory=list)
    quality: SummaryQuality = SummaryQuality.pass_
    issues: list[str] = Field(default_factory=list)


class ReportSection(BaseModel):
    topic_id: str
    topic_label: str
    hot: list[HotSummary] = Field(default_factory=list)
    general: list[ClusterSummary] = Field(default_factory=list)
