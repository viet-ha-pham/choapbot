from __future__ import annotations

import asyncio
from collections import defaultdict
from pathlib import Path
from tqdm import tqdm

from ..clustering import recursive_leiden, refine_clusters
from ..embeddings import Embedder
from ..graphing import build_similarity_graph, select_hot_doc_ids
from ..io import load_articles, load_config
from ..llm.client import JsonLLM
from ..models import ClusterSummary, HotSummary, NewsArticle, PipelineConfig, ReportSection
from ..preprocess import deduplicate, filter_noise, make_representative_chunk
from ..reporting.docx_writer import write_docx
from ..utils import estimate_tokens
from ..workflows.cluster import run_cluster
from ..workflows.hot import run_hot_article


def _order_sections(cfg: PipelineConfig, hot: list[HotSummary], general: list[ClusterSummary]) -> list[ReportSection]:
    by_topic: dict[str, ReportSection] = {}
    label_by_id = {t.id: t.label for t in cfg.ontology}
    for t in cfg.ontology:
        by_topic[t.id] = ReportSection(topic_id=t.id, topic_label=t.label)
    for h in hot:
        if h.topic_id not in by_topic:
            by_topic[h.topic_id] = ReportSection(topic_id=h.topic_id, topic_label=h.topic_label)
        by_topic[h.topic_id].hot.append(h)
    for c in general:
        if c.topic_id not in by_topic:
            by_topic[c.topic_id] = ReportSection(topic_id=c.topic_id, topic_label=c.topic_label)
        by_topic[c.topic_id].general.append(c)
    return [s for s in by_topic.values() if s.hot or s.general]


async def _run_hot_parallel(articles: list[NewsArticle], llm: JsonLLM, cfg: PipelineConfig) -> list[HotSummary]:
    sem = asyncio.Semaphore(cfg.max_parallel_llm_tasks)

    async def one(a: NewsArticle):
        async with sem:
            return await run_hot_article(a, llm, cfg)

    tasks = [one(a) for a in articles]
    return [await t for t in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="LLM hot")]


async def _run_clusters_parallel(clusters: list[list[str]], article_by_id: dict[str, NewsArticle], llm: JsonLLM, cfg: PipelineConfig) -> list[ClusterSummary]:
    sem = asyncio.Semaphore(cfg.max_parallel_llm_tasks)

    async def one(i: int, ids: list[str]):
        async with sem:
            arts = [article_by_id[x] for x in ids if x in article_by_id]
            return await run_cluster(f"cluster_{i:04d}", arts, llm, cfg)

    tasks = [one(i, ids) for i, ids in enumerate(clusters)]
    out: list[ClusterSummary] = []
    for fut in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="LLM clusters"):
        r = await fut
        if r is not None:
            out.append(r)
    return out


async def run_pipeline(input_jsonl: Path, config_path: Path, out_dir: Path) -> Path:
    cfg = load_config(config_path)
    articles = load_articles(input_jsonl)
    print(f"Loaded: {len(articles)}")

    articles = deduplicate(articles, cfg)
    print(f"After dedup: {len(articles)}")

    articles = filter_noise(articles, cfg)
    print(f"After noise filter: {len(articles)}")

    if not articles:
        raise RuntimeError("Không còn bài nào sau lọc.")

    chunks = [make_representative_chunk(a) for a in articles]
    embedder = Embedder(cfg.embedding_model)
    embeddings = embedder.encode_chunks(chunks)

    g = build_similarity_graph(chunks, embeddings, cfg)
    hot_ids = select_hot_doc_ids(g, cfg.hot_top_n)
    article_by_id = {a.doc_id: a for a in articles}
    hot_articles = [article_by_id[x] for x in hot_ids if x in article_by_id]
    non_hot_ids = [a.doc_id for a in articles if a.doc_id not in hot_ids]
    print(f"Hot: {len(hot_articles)} | Non-hot: {len(non_hot_ids)} | Graph edges: {g.number_of_edges()}")

    llm = JsonLLM(cfg.llm_model, cfg.llm_temperature)
    hot_summaries = await _run_hot_parallel(hot_articles, llm, cfg) if hot_articles else []

    token_by_doc = {c.doc_id: c.token_estimate + estimate_tokens(article_by_id[c.doc_id].content[:2500]) for c in chunks}
    raw_clusters = recursive_leiden(g, non_hot_ids, token_by_doc, cfg) if non_hot_ids else []
    clusters = refine_clusters(raw_clusters, token_by_doc, cfg)
    print(f"Clusters: raw={len(raw_clusters)} refined={len(clusters)}")

    cluster_summaries = await _run_clusters_parallel(clusters, article_by_id, llm, cfg) if clusters else []
    sections = _order_sections(cfg, hot_summaries, cluster_summaries)

    output_path = out_dir / f"{input_jsonl.stem}.docx"
    write_docx(sections, output_path, title=f"Báo cáo tổng hợp: {input_jsonl.stem}")
    return output_path
