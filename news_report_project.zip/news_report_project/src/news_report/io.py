from __future__ import annotations

from pathlib import Path
import yaml
from .models import NewsArticle, PipelineConfig
from .utils import iter_jsonl, stable_id


def load_config(path: Path) -> PipelineConfig:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return PipelineConfig.model_validate(data)


def load_articles(path: Path) -> list[NewsArticle]:
    articles: list[NewsArticle] = []
    for row in iter_jsonl(path):
        title = row.get("title", "")
        content = row.get("content", "")
        domain = row.get("domain", "")
        doc_id = row.get("doc_id") or stable_id(title, content, domain)
        articles.append(NewsArticle(doc_id=doc_id, title=title, content=content, domain=domain))
    return articles
