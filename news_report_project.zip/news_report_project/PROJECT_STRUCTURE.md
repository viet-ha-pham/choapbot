# Cấu trúc project

```text
news_report_project/
├── config/default.yaml              # ngưỡng, ontology, rule lọc nhiễu, LLM config
├── examples/sample.jsonl            # dữ liệu mẫu
├── pyproject.toml                   # dependency + CLI news-report
├── README.md
└── src/news_report/
    ├── cli.py                       # entrypoint CLI
    ├── models.py                    # Pydantic models
    ├── io.py                        # load config/jsonl
    ├── preprocess.py                # dedup, noise filter, representative chunk
    ├── embeddings.py                # SentenceTransformer embeddings
    ├── graphing.py                  # FAISS + similarity graph + PageRank
    ├── clustering.py                # recursive Leiden + cluster refinement
    ├── prompts.py                   # prompt chặt cho hot/non-hot/check/refine
    ├── llm/client.py                # OpenAI JSON LLM wrapper
    ├── workflows/hot.py             # LangGraph classify → summarize → check → refine
    ├── workflows/cluster.py         # LangGraph summarize → check → refine
    ├── pipeline/runner.py           # orchestration end-to-end + parallel LLM
    └── reporting/docx_writer.py     # xuất DOCX theo đề mục
```

## Điểm cần sửa khi vào production

- Thay SimHash đơn giản bằng MinHash/LSH nếu dữ liệu vài nghìn đến vài chục nghìn bài/ngày.
- Thêm cache embedding theo `doc_id` để không encode lại.
- Thêm cache LLM theo hash prompt để rerun không tốn tiền.
- Thêm observability: lưu intermediate `filtered.jsonl`, `hot_ids.json`, `clusters.json`, `summaries.json`.
- Thêm fallback local LLM/vLLM nếu không dùng OpenAI.
- Tune `similarity_threshold`, `faiss_k`, `hot_top_n`, `max_cluster_tokens` trên tập thật.
```
