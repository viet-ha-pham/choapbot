# News Report Pipeline

Pipeline cho file `jsonl` có 3 field: `title`, `content`, `domain`.

## Chạy nhanh

```bash
cd news_report_project
python -m venv .venv
source .venv/bin/activate
pip install -e .
export OPENAI_API_KEY=...
news-report run examples/sample.jsonl --config config/default.yaml --out-dir outputs
```

Kết quả DOCX sẽ có tên cùng stem với file jsonl, ví dụ `sample.docx`.

## Ý tưởng chính

1. Đọc JSONL → validate bằng Pydantic.
2. Lọc trùng theo normalized title+content và SimHash đơn giản.
3. Lọc bài không đáng quan tâm bằng rule title/content/domain.
4. Tạo representative text = title + lead + đoạn cuối.
5. Embedding bằng SentenceTransformer.
6. FAISS IndexFlatIP để lấy kNN.
7. Dựng similarity graph vô hướng có trọng số.
8. PageRank lấy top hot.
9. Hot articles chạy workflow LLM: classify ontology → summarize → self-check → refine.
10. Non-hot clustering đệ quy Leiden, refine cluster theo token budget.
11. Non-hot cluster chạy workflow tóm tắt đại thể song song.
12. Gộp theo đề mục và render DOCX.
