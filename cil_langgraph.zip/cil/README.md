# CIL: CoT-Informed Leiden Clustering

**CoT-Informed Leiden for Memory-Augmented Long Document Summarization**

---

## Ý tưởng cốt lõi

Clustering thông thường (ClusterMem, CluCoT) dùng **embedding similarity** → cluster coherent về mặt **lexical**.

CIL dùng **hybrid edge weight** = embedding + CoT descriptor + LLM judge → cluster coherent về mặt **argument**:

```
w(i,j) = α·s_emb(i,j)    # normalized inverse energy distance
        + β·s_cot(i,j)    # cosine(CoT_desc_emb_i, CoT_desc_emb_j)  
        + γ·s_llm(i,j)    # LLM binary judge (top-K pairs only)
```

Kết quả: Methods + Results chunk (cùng argument thread) cluster cùng nhau, dù vocabulary khác nhau. Limitations chunk tách khỏi Methods chunk dù cùng topic.

---

## Pipeline (5 stages)

```
Stage 1: Chunking → generate CoT descriptor per chunk (1 LLM call each)
           Claim | Theme | Key Terms (≤64 tokens)

Stage 2: Hybrid edge weighting → CIL Leiden clustering
           α·s_emb + β·s_cot + γ·s_llm → argument-coherent clusters

Stage 3: CoT memory-conditioned generation (per chunk)
           retrieve CoT memory → CoT reasoning (anchored by descriptor)
           → partial summary → update CoT memory (field-by-field)

Stage 4: Cross-cluster CoT synthesis → final summary
```

---

## Cài đặt

```bash
pip install -r requirements.txt
```

---

## Chạy

```bash
# 1 document
python scripts/run_single.py --input data/samples/paper.txt

# Batch arXiv test (100 samples)
python scripts/run_dataset.py --dataset arxiv --split test --num-samples 100

# Ablation: không có LLM judge (γ=0)
python scripts/run_dataset.py --dataset arxiv --split test --gamma 0

# Ablation: embedding-only (= CluCoT clustering)
python scripts/run_dataset.py --dataset arxiv --split test --alpha 1.0 --beta 0.0 --gamma 0.0

# Evaluate
python scripts/evaluate.py --pred-dir outputs/arxiv_test/
```

---

## Cấu hình hybrid weights

```yaml
cil_clustering:
  alpha: 0.4    # sentence embedding (energy distance)
  beta:  0.4    # CoT descriptor cosine similarity
  gamma: 0.2    # LLM binary judge (top-20 pairs per chunk)
  top_k_judge: 20
```

**Ablation variants:**
| Config | Meaning |
|--------|---------|
| α=1.0, β=0.0, γ=0.0 | Embedding-only (= CluCoT/ClusterMem) |
| α=0.4, β=0.6, γ=0.0 | No LLM judge (fast) |
| α=0.4, β=0.4, γ=0.2 | Full CIL (default) |

---

## Output JSON

```json
{
  "summary": "...",
  "cluster_quality": {
    "K": 4,
    "argument_coherence_score": 0.79,
    "intra_cot_similarity": 0.81
  },
  "descriptors": [
    {"claim": "...", "theme": "methodology", "key_terms": "attention, transformer"},
    ...
  ],
  "cot_chains": [...],
  "final_cot_memories": { "0": {...}, "1": {...} }
}
```

---

## So sánh với các phiên bản trước

| | ClusterMem | CluCoT | **CIL** |
|--|--|--|--|
| Clustering | Emb-only Leiden | Emb-only Leiden | **Hybrid CoT-Informed Leiden** |
| Memory content | Plain summary | CoT chain | CoT chain |
| Pre-cluster step | ✗ | ✗ | **CoT descriptor** |
| Bidirectional CoT↔Cluster | ✗ | ✗ | **✓** |
| ACS (arXiv) | 0.58 | 0.58 | **0.79** |
| AlignScore (arXiv) | 71.8 | 74.6 | **78.8** |

## LangGraph orchestration

This fork adds `CILLangGraphPipeline`, a LangGraph rewrite of the original
linear `CILPipeline`. The algorithm is unchanged; only orchestration changes.
CoT memory is represented as graph state and updated inside a loop node.

```python
from cil import CILLangGraphPipeline

pipeline = CILLangGraphPipeline("config.yaml")
result = pipeline.run(document_text)
print(result.summary)
```

Run one document:

```bash
python scripts/run_single_langgraph.py --input data/samples/paper.txt
```

A cheaper practical mode disables the pairwise LLM judge:

```bash
python scripts/run_single_langgraph.py --input paper.txt --gamma 0 --top-k 0
```

Save the graph as Mermaid:

```bash
python scripts/run_single_langgraph.py --input paper.txt --save-graph outputs/cil_graph.mmd
```

LangGraph flow:

```mermaid
graph TD
    chunk -->|empty| empty
    chunk -->|single| single_chunk
    chunk -->|many| embed
    embed --> descriptor
    descriptor --> cluster
    cluster --> init_memory
    init_memory --> process_chunk
    process_chunk -->|continue| process_chunk
    process_chunk -->|final| final
```
