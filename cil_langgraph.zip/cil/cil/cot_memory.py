"""
cot_memory.py
CoT Memory Bank — core novelty của CluCoT.

Mỗi memory slot lưu một structured CoT reasoning chain gồm 4 trường:
  - Claim:      Luận điểm chính của cluster
  - Evidence:   Bằng chứng/kết quả hỗ trợ
  - Implication: Hàm ý cho argument tổng thể của document
  - Cross-link: Liên kết với các cluster khác

Thay vì lưu plain compressed summary (như ClusterMem),
CluCoT lưu structured reasoning — khi retrieve, model có
inferential scaffolding chứ không chỉ factual context.
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class CoTChain:
    """
    Structured CoT reasoning chain cho một cluster.
    Mỗi field có token budget riêng (tổng = tau = 256 tokens).
    """
    claim:       str = ""   # 64 tokens — main assertion
    evidence:    str = ""   # 96 tokens — supporting facts/results
    implication: str = ""   # 64 tokens — consequence for doc argument
    cross_link:  str = ""   # 32 tokens — relation to other clusters

    def is_empty(self) -> bool:
        return not any([self.claim, self.evidence, self.implication, self.cross_link])

    def to_prompt_str(self) -> str:
        """Format để đưa vào prompt LLM."""
        parts = []
        if self.claim:
            parts.append(f"Claim: {self.claim}")
        if self.evidence:
            parts.append(f"Evidence: {self.evidence}")
        if self.implication:
            parts.append(f"Implication: {self.implication}")
        if self.cross_link:
            parts.append(f"Cross-link: {self.cross_link}")
        return "\n".join(parts) if parts else "(empty)"

    def to_dict(self) -> Dict[str, str]:
        return {
            "claim": self.claim,
            "evidence": self.evidence,
            "implication": self.implication,
            "cross_link": self.cross_link,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, str]) -> "CoTChain":
        return cls(
            claim=d.get("claim", ""),
            evidence=d.get("evidence", ""),
            implication=d.get("implication", ""),
            cross_link=d.get("cross_link", ""),
        )

    @classmethod
    def from_llm_output(cls, text: str) -> "CoTChain":
        """
        Parse LLM output thành CoTChain.
        LLM được prompt để output theo format:
          Claim: ...
          Evidence: ...
          Implication: ...
          Cross-link: ...
        """
        chain = cls()
        current_field = None
        current_lines = []

        field_map = {
            "claim":       "claim",
            "evidence":    "evidence",
            "implication": "implication",
            "cross-link":  "cross_link",
            "cross_link":  "cross_link",
            "crosslink":   "cross_link",
        }

        for line in text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue

            matched = False
            for prefix, attr in field_map.items():
                if line.lower().startswith(prefix + ":"):
                    # Lưu field trước
                    if current_field:
                        setattr(chain, current_field, " ".join(current_lines).strip())
                    current_field = attr
                    current_lines = [line[len(prefix)+1:].strip()]
                    matched = True
                    break

            if not matched and current_field:
                current_lines.append(line)

        # Lưu field cuối
        if current_field and current_lines:
            setattr(chain, current_field, " ".join(current_lines).strip())

        # Fallback nếu parse lỗi: đặt toàn bộ vào claim
        if chain.is_empty() and text.strip():
            chain.claim = text.strip()[:300]

        return chain


@dataclass
class CoTMemorySlot:
    cluster_id: int
    chain: CoTChain = field(default_factory=CoTChain)
    update_count: int = 0
    chunk_history: List[int] = field(default_factory=list)


class CoTMemoryBank:
    """
    Memory bank index theo cluster identity.
    Content của mỗi slot là CoTChain (structured reasoning),
    không phải plain summary.

    So với ClusterMem:
      ClusterMem:  m_k = "Section discusses attention mechanism."
      CluCoT:      m_k = CoTChain(
                     claim="Self-attention replaces RNNs",
                     evidence="BLEU +2.0 on WMT-14",
                     implication="Parallelism enables scale",
                     cross_link="Connects to training efficiency cluster"
                   )
    """

    def __init__(self, K: int, budgets: Optional[Dict[str, int]] = None):
        """
        Args:
            K: Số clusters
            budgets: Token budget per field (default: claim=64, evidence=96,
                     implication=64, cross_link=32)
        """
        self.K = K
        self.budgets = budgets or {
            "claim":       64,
            "evidence":    96,
            "implication": 64,
            "cross_link":  32,
        }
        self.slots: Dict[int, CoTMemorySlot] = {
            k: CoTMemorySlot(cluster_id=k) for k in range(K)
        }

    def get(self, cluster_id: int) -> CoTChain:
        """Lấy current CoT chain của cluster k."""
        slot = self.slots.get(cluster_id)
        if slot is None:
            logger.warning(f"Cluster {cluster_id} not in bank (K={self.K})")
            return CoTChain()
        return slot.chain

    def is_empty(self, cluster_id: int) -> bool:
        return self.get(cluster_id).is_empty()

    def update(self, cluster_id: int, new_chain: CoTChain, chunk_idx: int):
        """Cập nhật memory slot với CoT chain mới."""
        if cluster_id not in self.slots:
            self.slots[cluster_id] = CoTMemorySlot(cluster_id=cluster_id)
        self.slots[cluster_id].chain = new_chain
        self.slots[cluster_id].update_count += 1
        self.slots[cluster_id].chunk_history.append(chunk_idx)

    def all_chains(self) -> Dict[int, CoTChain]:
        """Trả về tất cả CoT chains."""
        return {k: s.chain for k, s in self.slots.items()}

    def all_chains_as_dict(self) -> Dict[int, Dict]:
        """Serialize để lưu JSON."""
        return {k: s.chain.to_dict() for k, s in self.slots.items()}

    def stats(self) -> Dict:
        return {
            "K": self.K,
            "non_empty": sum(1 for s in self.slots.values() if not s.chain.is_empty()),
            "avg_updates": sum(s.update_count for s in self.slots.values()) / max(1, self.K),
            "budgets": self.budgets,
        }

    def reset(self):
        for s in self.slots.values():
            s.chain = CoTChain()
            s.update_count = 0
            s.chunk_history = []
