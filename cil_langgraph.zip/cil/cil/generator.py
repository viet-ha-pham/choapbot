"""
generator.py — LLM calls cho CIL.

Thêm so với CluCoT:
  - generate_descriptor(): CoT descriptor trước clustering (Stage 1)
  - judge_argument_compatibility(): binary judge cho top-K pairs (Stage 2)

Giữ nguyên:
  - generate_cot_reasoning(): per-chunk CoT conditioned on descriptor + memory
  - generate_partial_summary(), update_cot_memory(), generate_final_summary()
"""

import logging
from typing import Dict, List, Optional
from openai import OpenAI
from .cot_memory import CoTChain
from .cot_descriptor import CoTDescriptor

logger = logging.getLogger(__name__)


class LLMGenerator:
    def __init__(
        self,
        base_url:             str   = "http://localhost:8000/v1",
        model:                str   = "Qwen3-8B",
        api_key:              str   = "EMPTY",
        temperature:          float = 0.0,
        max_tokens_desc:      int   = 80,    # CoT descriptor
        max_tokens_judge:     int   = 5,     # binary judge
        max_tokens_cot:       int   = 300,   # per-chunk CoT reasoning
        max_tokens_partial:   int   = 200,   # partial summary
        max_tokens_update:    int   = 280,   # memory update
        max_tokens_final:     int   = 512,   # final synthesis
        timeout:              int   = 120,
    ):
        self.client      = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout)
        self.model       = model
        self.temperature = temperature
        self.max_tokens_desc    = max_tokens_desc
        self.max_tokens_judge   = max_tokens_judge
        self.max_tokens_cot     = max_tokens_cot
        self.max_tokens_partial = max_tokens_partial
        self.max_tokens_update  = max_tokens_update
        self.max_tokens_final   = max_tokens_final

    def _call(self, prompt: str, max_tokens: int, system: str = "") -> str:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        try:
            resp = self.client.chat.completions.create(
                model=self.model, messages=messages,
                temperature=self.temperature, max_tokens=max_tokens,
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            return ""

    # ── Stage 1: CoT Descriptor Generation ──────────────────

    def generate_descriptor(self, chunk_text: str) -> CoTDescriptor:
        """
        1 LLM call per chunk → lightweight CoT descriptor cho clustering.
        """
        prompt = f"""[CHUNK]
{chunk_text[:800]}

[INSTRUCTION]
Characterize this chunk in structured form for thematic clustering.

Claim: The main assertion or contribution in ONE sentence (≤24 tokens).
Theme: The discourse function in 2-4 words. Choose from:
  "motivation", "methodology", "experimental setup", "results",
  "analysis", "limitations", "related work", "background", "conclusion"
Key Terms: 3-5 domain-specific anchor terms, comma-separated.

Output EXACTLY in this format:
Claim: <your claim>
Theme: <your theme>
Key Terms: <term1>, <term2>, <term3>"""

        raw = self._call(
            prompt, self.max_tokens_desc,
            system="You characterize document chunks for thematic clustering. Be concise."
        )
        return CoTDescriptor.from_llm_output(raw)

    # ── Stage 2: LLM Argument Compatibility Judge ─────────────

    def judge_argument_compatibility(
        self,
        desc_i: CoTDescriptor,
        desc_j: CoTDescriptor,
    ) -> int:
        """
        Binary judge: are desc_i and desc_j argumentatively compatible?
        Returns 1 (compatible) or 0 (incompatible).
        Only called for top-K candidate pairs.
        """
        prompt = f"""Chunk A:
Claim: {desc_i.claim}
Theme: {desc_i.theme}

Chunk B:
Claim: {desc_j.claim}
Theme: {desc_j.theme}

Are these two chunks arguing the same point or serving the same argumentative function in the document?
Answer with ONLY "1" (yes, compatible) or "0" (no, incompatible)."""

        raw = self._call(prompt, self.max_tokens_judge,
                         system="Answer only 1 or 0.")
        try:
            return int(raw.strip()[0])
        except (ValueError, IndexError):
            return 0

    # ── Stage 3: Per-chunk CoT reasoning ────────────────────

    def generate_cot_reasoning(
        self,
        chunk_text:     str,
        descriptor:     CoTDescriptor,   # pre-cluster descriptor (NEW vs CluCoT)
        cot_memory:     CoTChain,
        cluster_id:     int,
        other_clusters: Optional[List[int]] = None,
    ) -> CoTChain:
        """
        Prompt P_cot: chunk + pre-cluster descriptor + accumulated CoT memory
        → per-chunk CoT reasoning chain.

        Khác CluCoT: có thêm descriptor làm anchor argument role.
        """
        system = "You are a scientific reasoning assistant."
        mem_str  = cot_memory.to_prompt_str() if not cot_memory.is_empty() \
                   else "(no prior reasoning in this cluster)"
        desc_str = descriptor.to_prompt_str() if not descriptor.is_empty() \
                   else "(no descriptor)"
        others_hint = (f"Other thematic clusters: {other_clusters}"
                       if other_clusters else "")

        prompt = f"""[PRE-CLUSTER DESCRIPTOR — This chunk's argumentative role]
{desc_str}

[ACCUMULATED CoT MEMORY — Cluster {cluster_id}]
{mem_str}

[CURRENT CHUNK]
{chunk_text}

{others_hint}

[INSTRUCTION]
Using your pre-cluster descriptor as an anchor for your argumentative role,
reason through this chunk step-by-step and EXTEND the accumulated memory:

Step 1 — Claim: Extend or refine the claim (consistent with descriptor).
Step 2 — Evidence: Add new specific facts, results, or observations.
Step 3 — Implication: Update the implication chain.
Step 4 — Cross-link: Identify connections to other thematic clusters.

Output EXACTLY:
Claim: <claim>
Evidence: <evidence>
Implication: <implication>
Cross-link: <cross-link>"""

        raw = self._call(prompt, self.max_tokens_cot, system)
        chain = CoTChain.from_llm_output(raw)
        logger.debug(f"CoT reasoning cluster {cluster_id}: claim='{chain.claim[:50]}...'")
        return chain

    # ── Stage 3: Partial summary ─────────────────────────────

    def generate_partial_summary(
        self,
        chunk_text:  str,
        descriptor:  CoTDescriptor,
        cot_memory:  CoTChain,
        new_cot:     CoTChain,
        cluster_id:  int,
    ) -> str:
        system = "You are a scientific document summarizer."
        prompt = f"""[ARGUMENT ROLE (Pre-cluster Descriptor)]
{descriptor.to_prompt_str()}

[CLUSTER CoT MEMORY]
{cot_memory.to_prompt_str() if not cot_memory.is_empty() else "(first chunk in cluster)"}

[NEW CoT REASONING]
{new_cot.to_prompt_str()}

[CURRENT CHUNK]
{chunk_text}

[INSTRUCTION]
Write a concise summary (2-3 sentences) grounded in the CoT reasoning.
Avoid repeating content already in the cluster memory.

Summary:"""
        result = self._call(prompt, self.max_tokens_partial, system)
        logger.debug(f"Partial summary cluster {cluster_id}: {result[:80]}...")
        return result

    # ── Stage 3: Memory update ───────────────────────────────

    def update_cot_memory(
        self,
        old_cot:    CoTChain,
        new_cot:    CoTChain,
        budgets:    Dict[str, int],
        cluster_id: int,
    ) -> CoTChain:
        if old_cot.is_empty():
            return new_cot
        system = "You maintain structured reasoning memory for a scientific document cluster."
        prompt = f"""[EXISTING MEMORY]
{old_cot.to_prompt_str()}

[NEW REASONING]
{new_cot.to_prompt_str()}

[INSTRUCTION]
Merge field-by-field:
- Claim ({budgets['claim']} tokens): Generalize to cover both.
- Evidence ({budgets['evidence']} tokens): Integrate, remove redundancy.
- Implication ({budgets['implication']} tokens): Update implication chain.
- Cross-link ({budgets['cross_link']} tokens): Extend connections.

Output EXACTLY:
Claim: <merged>
Evidence: <merged>
Implication: <merged>
Cross-link: <merged>"""

        raw = self._call(prompt, self.max_tokens_update, system)
        merged = CoTChain.from_llm_output(raw)
        if not merged.claim:       merged.claim       = old_cot.claim
        if not merged.evidence:    merged.evidence    = old_cot.evidence
        if not merged.implication: merged.implication = old_cot.implication
        if not merged.cross_link:  merged.cross_link  = old_cot.cross_link
        return merged

    # ── Stage 4: Cross-cluster synthesis ────────────────────

    def generate_final_summary(
        self,
        all_cot_chains:    Dict[int, "CoTChain"],
        partial_summaries: List[str],
    ) -> str:
        system = "You synthesize structured reasoning from multiple thematic clusters."
        chains_str = "\n".join(
            f"[Cluster {k+1}]\n{chain.to_prompt_str()}"
            for k, chain in sorted(all_cot_chains.items())
            if not chain.is_empty()
        )
        prompt = f"""[CLUSTER CoT MEMORIES]
{chains_str}

[INSTRUCTION]
Synthesize a scientific abstract via cross-cluster reasoning:

Step 1 — Central problem (from motivation/background clusters)?
Step 2 — Proposed approach and justification (methodology clusters)?
Step 3 — Key results and significance (results clusters)?
Step 4 — Conclusion and implications (cross all clusters)?

Write a 4-6 sentence abstractive summary following this reasoning.

Summary:"""
        result = self._call(prompt, self.max_tokens_final, system)
        logger.info(f"Final summary: {result[:100]}...")
        return result

    # ── D2CS-style refinement helpers ───────────────────────

    def cluster_summary(self, text: str) -> str:
        return self._call(f"Summarize in 1-2 sentences:\n\n{text[:1000]}\n\nSummary:", 100)

    def coherence_score(self, a: str, b: str, summary: str) -> float:
        raw = self._call(
            f"[Theme]: {summary[:200]}\n[A]: {a[:200]}\n[B]: {b[:200]}\n"
            f"Consistency (0.0-1.0):", 5)
        try: return max(0.0, min(1.0, float(raw.strip().split()[0])))
        except: return 0.5
