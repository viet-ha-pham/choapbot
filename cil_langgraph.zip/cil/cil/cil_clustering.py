"""
cil_clustering.py
CoT-Informed Leiden (CIL) — core algorithm.

Hybrid edge weight:
  w(i,j) = α · s_emb(i,j)   # normalized inverse energy distance
          + β · s_cot(i,j)   # cosine(cot_desc_emb_i, cot_desc_emb_j)
          + γ · s_llm(i,j)   # LLM binary judge (top-K pairs only)

So với embedding-only Leiden (D2CS):
  - D2CS:  w = f(energy_distance(X_i, X_j))
  - CIL:   w = α·s_emb + β·s_cot + γ·s_llm

Kết quả: cluster coherent ở mức argument,
không chỉ mức lexical/semantic.
"""

import logging
import numpy as np
from collections import Counter
from typing import List, Dict, Tuple, Optional
from scipy.spatial.distance import cdist
from sklearn.decomposition import PCA
from sklearn.neighbors import KernelDensity
import igraph as ig
import leidenalg

logger = logging.getLogger(__name__)


# ── Energy Distance ──────────────────────────────────────────

def energy_distance(X: np.ndarray, Y: np.ndarray) -> float:
    if len(X) == 0 or len(Y) == 0:
        return 1.0
    cross = cdist(X, Y).mean()
    def intra(A):
        if len(A) < 2: return 0.0
        d = cdist(A, A); np.fill_diagonal(d, 0)
        return d.sum() / (len(A) * (len(A) - 1))
    return max(0.0, 2 * cross - intra(X) - intra(Y))

def compute_emb_similarity_matrix(
    chunk_embeddings: List[np.ndarray],
) -> np.ndarray:
    """
    Tính normalized inverse energy distance matrix (N×N).
    s_emb(i,j) = 1 - Δ(i,j) / max(Δ) ∈ [0,1], higher = more similar.
    """
    N = len(chunk_embeddings)
    D = np.zeros((N, N))
    for i in range(N):
        for j in range(i + 1, N):
            d = energy_distance(chunk_embeddings[i], chunk_embeddings[j])
            D[i, j] = D[j, i] = d
    # Normalize to similarity
    max_d = D.max() + 1e-8
    S_emb = 1.0 - D / max_d
    np.fill_diagonal(S_emb, 0.0)  # self-loop = 0
    return S_emb


# ── CoT Descriptor Similarity ────────────────────────────────

def compute_cot_similarity_matrix(
    descriptor_embeddings: np.ndarray,  # (N, d), L2-normalized
) -> np.ndarray:
    """
    s_cot(i,j) = cosine(t_i, t_j) ∈ [-1,1] → clipped to [0,1].
    No extra LLM calls — O(N²) dot products.
    """
    S_cot = descriptor_embeddings @ descriptor_embeddings.T  # (N, N)
    S_cot = np.clip(S_cot, 0.0, 1.0)
    np.fill_diagonal(S_cot, 0.0)
    return S_cot


# ── LLM Judge (top-K pairs only) ─────────────────────────────

def compute_llm_judge_matrix(
    descriptors,           # List[CoTDescriptor]
    llm_generator,
    candidate_scores: np.ndarray,  # (N, N) pre-scores for top-K selection
    top_k: int = 20,
) -> np.ndarray:
    """
    Binary LLM judge: s_llm(i,j) ∈ {0,1}.
    Chỉ judge top-K pairs per chunk → O(N·K) calls thay vì O(N²).
    """
    N = len(descriptors)
    S_llm = np.zeros((N, N))

    for i in range(N):
        # Lấy top-K ứng viên (loại self)
        scores_i = candidate_scores[i].copy()
        scores_i[i] = -1.0
        top_k_idx = np.argsort(scores_i)[::-1][:top_k]

        for j in top_k_idx:
            if i == j or S_llm[i, j] != 0:
                continue
            score = llm_generator.judge_argument_compatibility(
                descriptors[i], descriptors[j]
            )
            S_llm[i, j] = S_llm[j, i] = float(score)

    return S_llm


# ── KDE Filtering ────────────────────────────────────────────

def kde_filter(chunk_embeddings, bw=0.5, plo=5, phi=95):
    all_e = np.vstack(chunk_embeddings)
    nc = min(10, all_e.shape[1], all_e.shape[0] - 1)
    low = PCA(n_components=nc).fit_transform(all_e)
    dens = KernelDensity(bandwidth=bw).fit(low).score_samples(low)
    lo, hi = np.percentile(dens, plo), np.percentile(dens, phi)
    res, idx = [], 0
    for e in chunk_embeddings:
        n = len(e)
        mask = (dens[idx:idx+n] >= lo) & (dens[idx:idx+n] <= hi)
        res.append(e[mask] if mask.sum() > 0 else e)
        idx += n
    return res


# ── Graph Construction ───────────────────────────────────────

def build_hybrid_knn_graph(
    W: np.ndarray,  # (N, N) final hybrid weight matrix
    k: int = 5,
) -> ig.Graph:
    """KNN graph từ hybrid similarity matrix."""
    N = W.shape[0]
    edges, weights, seen = [], [], set()
    for i in range(N):
        row = W[i].copy(); row[i] = -np.inf
        for j in np.argsort(row)[::-1][:k]:
            key = (min(i, j), max(i, j))
            if key not in seen:
                seen.add(key)
                edges.append((i, j))
                weights.append(max(0.0, row[j]))
    G = ig.Graph(n=N, edges=edges, directed=False)
    G.es["weight"] = weights
    return G


def leiden_cluster(G: ig.Graph, resolution: float = 1.0, seed: int = 42) -> List[int]:
    part = leidenalg.find_partition(
        G, leidenalg.RBConfigurationVertexPartition,
        weights="weight", resolution_parameter=resolution,
        seed=seed, n_iterations=10,
    )
    labels = [0] * G.vcount()
    for cid, members in enumerate(part):
        for node in members:
            labels[node] = cid
    return labels


# ── CIL Main Class ───────────────────────────────────────────

class CILClustering:
    """
    CoT-Informed Leiden Clustering.

    Hybrid edge weight:
      w(i,j) = α·s_emb(i,j) + β·s_cot(i,j) + γ·s_llm(i,j)

    So với D2CSClustering (embedding-only):
      - Thêm CoT descriptor embeddings (s_cot)
      - Thêm LLM argument compatibility judge (s_llm, top-K only)
      - Leiden chạy trên hybrid graph → argument-coherent clusters
    """

    def __init__(
        self,
        alpha: float = 0.4,          # weight cho s_emb
        beta:  float = 0.4,          # weight cho s_cot
        gamma: float = 0.2,          # weight cho s_llm
        knn_k: int = 5,
        leiden_resolution: float = 1.0,
        top_k_judge: int = 20,       # chỉ judge top-K pairs per chunk
        min_cluster_size: int = 2,
        kde_bandwidth: float = 0.5,
        kde_percentile_low: float = 5,
        kde_percentile_high: float = 95,
        llm_generator=None,
    ):
        self.alpha = alpha
        self.beta  = beta
        self.gamma = gamma
        self.knn_k = knn_k
        self.resolution = leiden_resolution
        self.top_k = top_k_judge
        self.min_cs = min_cluster_size
        self.kde_bw = kde_bandwidth
        self.kde_plo = kde_percentile_low
        self.kde_phi = kde_percentile_high
        self.llm = llm_generator

    def fit(
        self,
        chunk_embeddings: List[np.ndarray],   # sentence emb per chunk
        descriptor_embeddings: np.ndarray,     # (N, d) CoT desc embeddings
        descriptors,                            # List[CoTDescriptor]
    ) -> Tuple[List[int], Dict]:
        """
        Chạy CIL clustering.

        Returns:
            labels: List[int] cluster label mỗi chunk
            info:   Dict thông tin debug
        """
        N = len(chunk_embeddings)
        logger.info(f"CIL clustering: N={N}, α={self.alpha}, β={self.beta}, γ={self.gamma}")

        if N <= 2:
            return [0] * N, {"K": 1, "degenerate": False}

        # ── 1. KDE filter sentence embeddings ────────────────
        filtered = kde_filter(chunk_embeddings, self.kde_bw, self.kde_plo, self.kde_phi)

        # ── 2. Embedding similarity matrix ───────────────────
        logger.info("  Computing embedding similarity (energy distance)...")
        S_emb = compute_emb_similarity_matrix(filtered)

        # ── 3. CoT descriptor similarity matrix ──────────────
        logger.info("  Computing CoT descriptor similarity (cosine)...")
        S_cot = compute_cot_similarity_matrix(descriptor_embeddings)

        # ── 4. LLM judge (top-K pairs only) ──────────────────
        if self.gamma > 0 and self.llm is not None:
            logger.info(f"  Running LLM judge (top-{self.top_k} pairs per chunk)...")
            candidate_scores = self.alpha * S_emb + self.beta * S_cot
            S_llm = compute_llm_judge_matrix(
                descriptors, self.llm, candidate_scores, top_k=self.top_k
            )
        else:
            S_llm = np.zeros((N, N))

        # ── 5. Hybrid weight matrix ───────────────────────────
        W = self.alpha * S_emb + self.beta * S_cot + self.gamma * S_llm
        logger.info(
            f"  Hybrid W: emb_contrib={self.alpha:.1f}, "
            f"cot_contrib={self.beta:.1f}, llm_contrib={self.gamma:.1f}"
        )

        # ── 6. KNN graph + Leiden ─────────────────────────────
        k = min(self.knn_k, N - 1)
        G = build_hybrid_knn_graph(W, k=k)
        labels = leiden_cluster(G, self.resolution)
        logger.info(f"  Initial K={len(set(labels))}")

        # ── 7. Merge small clusters ───────────────────────────
        labels = self._merge_small(labels, W)
        K = len(set(labels))
        logger.info(f"  Final K={K}")

        # ── 8. Compute cluster quality metrics ────────────────
        acs = self._argument_coherence_score(labels, S_cot, threshold=0.7)
        intra_sim = self._intra_cluster_cot_sim(labels, S_cot)

        info = {
            "K": K,
            "degenerate": K > N // 2,
            "hybrid_matrix": W,
            "S_emb": S_emb,
            "S_cot": S_cot,
            "S_llm": S_llm,
            "argument_coherence_score": acs,
            "intra_cot_similarity": intra_sim,
        }
        logger.info(f"  ACS={acs:.3f}, IntraCoTSim={intra_sim:.3f}")
        return labels, info

    def _merge_small(self, labels: List[int], W: np.ndarray) -> List[int]:
        N = len(labels); labels = list(labels)
        changed = True
        while changed:
            changed = False
            for k, c in Counter(labels).items():
                if c < self.min_cs:
                    others = [o for o in set(labels) if o != k]
                    if not others: break
                    def dist_to(o):
                        mi = [i for i in range(N) if labels[i] == k]
                        mo = [i for i in range(N) if labels[i] == o]
                        return -np.mean([W[a, b] for a in mi for b in mo])
                    near = min(others, key=dist_to)
                    labels = [near if l == k else l for l in labels]
                    changed = True; break
        unique = sorted(set(labels))
        remap = {o: n for n, o in enumerate(unique)}
        return [remap[l] for l in labels]

    def _argument_coherence_score(
        self, labels: List[int], S_cot: np.ndarray, threshold: float = 0.7
    ) -> float:
        """
        ACS: fraction of intra-cluster chunk pairs với CoT sim ≥ threshold.
        Đo lường argument compatibility trong mỗi cluster.
        """
        N = len(labels)
        total, coherent = 0, 0
        for i in range(N):
            for j in range(i + 1, N):
                if labels[i] == labels[j]:
                    total += 1
                    if S_cot[i, j] >= threshold:
                        coherent += 1
        return coherent / max(1, total)

    def _intra_cluster_cot_sim(self, labels: List[int], S_cot: np.ndarray) -> float:
        """Mean intra-cluster CoT descriptor cosine similarity."""
        N = len(labels)
        vals = []
        for i in range(N):
            for j in range(i + 1, N):
                if labels[i] == labels[j]:
                    vals.append(S_cot[i, j])
        return float(np.mean(vals)) if vals else 0.0
