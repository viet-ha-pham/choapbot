"""
pipeline.py — CIL main pipeline.

Thay đổi so với CluCoT:
  Stage 1 (MỚI): Generate CoT descriptors + encode → t_i
  Stage 2 (MỚI): Hybrid edge weighting (α·s_emb + β·s_cot + γ·s_llm) → CIL Leiden
  Stage 3: CoT memory generation (giống CluCoT nhưng thêm descriptor làm anchor)
  Stage 4: Cross-cluster synthesis (giống CluCoT)
"""

import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import yaml

from .chunker import Chunker, Chunk
from .embedder import SentenceEmbedder
from .cot_descriptor import CoTDescriptor, CoTDescriptorGenerator
from .cil_clustering import CILClustering
from .cot_memory import CoTMemoryBank, CoTChain
from .generator import LLMGenerator

logger = logging.getLogger(__name__)


@dataclass
class CILResult:
    summary: str
    chunks:             List[Chunk]      = field(default_factory=list)
    cluster_labels:     List[int]        = field(default_factory=list)
    num_clusters:       int              = 0
    descriptors:        List[Dict]       = field(default_factory=list)
    cot_chains:         List[Dict]       = field(default_factory=list)
    partial_summaries:  List[str]        = field(default_factory=list)
    final_cot_memories: Dict[int, Dict]  = field(default_factory=dict)
    cluster_quality:    Dict             = field(default_factory=dict)
    elapsed_sec:        float            = 0.0
    degenerate_fallback: bool            = False


class CILPipeline:
    """
    CIL: CoT-Informed Leiden for Memory-Augmented Long Document Summarization.

    Sử dụng:
        pipeline = CILPipeline("config.yaml")
        result   = pipeline.run(document_text)
        print(result.summary)
    """

    DEFAULT_CONFIG = {
        "llm": {
            "base_url":           "http://localhost:8000/v1",
            "model":              "Qwen3-8B",
            "api_key":            "EMPTY",
            "temperature":        0.0,
            "max_tokens_desc":    80,
            "max_tokens_judge":   5,
            "max_tokens_cot":     300,
            "max_tokens_partial": 200,
            "max_tokens_update":  280,
            "max_tokens_final":   512,
            "timeout":            120,
        },
        "chunking":  {"chunk_size": 512, "overlap": 50, "min_chunk_size": 100},
        "embedding": {"model_name": "all-mpnet-base-v2", "device": "cpu",
                      "batch_size": 64, "normalize": True},
        "cil_clustering": {
            "alpha": 0.4,              # weight: sentence embedding similarity
            "beta":  0.4,              # weight: CoT descriptor similarity
            "gamma": 0.2,              # weight: LLM judge
            "knn_k": 5,
            "leiden_resolution": 1.0,
            "top_k_judge": 20,         # top-K pairs per chunk cho LLM judge
            "min_cluster_size": 2,
            "kde_bandwidth": 0.5,
            "kde_percentile_low": 5,
            "kde_percentile_high": 95,
        },
        "cot_memory": {
            "budgets": {"claim": 64, "evidence": 96, "implication": 64, "cross_link": 32}
        },
        "pipeline":  {"fallback_to_sequential": True},
        "output":    {
            "save_descriptors":      True,
            "save_cot_chains":       True,
            "save_partial_summaries": True,
            "save_final_memories":   True,
            "save_cluster_quality":  True,
            "log_level":             "INFO",
        },
    }

    def __init__(self, config_path: Optional[str] = None, **overrides):
        self.config = self._load_config(config_path, overrides)
        self._setup_logging()
        logger.info("Initializing CIL pipeline...")

        self.chunker   = Chunker(**self.config["chunking"])
        self.embedder  = SentenceEmbedder(**self.config["embedding"])
        self.generator = LLMGenerator(**self.config["llm"])

        # CoT descriptor generator (reuse SBERT từ embedder)
        self.desc_gen  = CoTDescriptorGenerator(
            llm_generator=self.generator,
            sbert_model=self.embedder.model,
        )

        self.clustering = CILClustering(
            **self.config["cil_clustering"],
            llm_generator=self.generator,
        )
        self.cot_budgets = self.config["cot_memory"]["budgets"]
        logger.info("CIL pipeline ready.")

    def _load_config(self, config_path, overrides):
        import copy
        cfg = copy.deepcopy(self.DEFAULT_CONFIG)
        if config_path and Path(config_path).exists():
            with open(config_path) as f:
                file_cfg = yaml.safe_load(f) or {}
            for sec, vals in file_cfg.items():
                if sec in cfg and isinstance(vals, dict):
                    cfg[sec].update(vals)
                else:
                    cfg[sec] = vals
        for key, val in overrides.items():
            for sec in cfg:
                if isinstance(cfg[sec], dict) and key in cfg[sec]:
                    cfg[sec][key] = val
        return cfg

    def _setup_logging(self):
        level = getattr(logging, self.config["output"].get("log_level", "INFO"))
        logging.basicConfig(
            format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            datefmt="%H:%M:%S", level=level,
        )

    def run(self, document: str) -> CILResult:
        """Chạy CIL pipeline trên một document dài."""
        t0 = time.time()
        result = CILResult(summary="")

        # ── 1. Chunking ──────────────────────────────────────
        logger.info("Step 1/5: Chunking...")
        chunks = self.chunker.chunk(document)
        result.chunks = chunks
        N = len(chunks)
        if N == 0:
            logger.error("No chunks produced."); return result
        if N == 1:
            desc = self.generator.generate_descriptor(chunks[0].text)
            cot  = self.generator.generate_cot_reasoning(
                chunks[0].text, desc, CoTChain(), cluster_id=0)
            result.summary = self.generator.generate_partial_summary(
                chunks[0].text, desc, CoTChain(), cot, cluster_id=0)
            result.elapsed_sec = time.time() - t0
            return result

        # ── 2. Sentence Embedding ─────────────────────────────
        logger.info("Step 2/5: Sentence embedding...")
        chunk_embs = self.embedder.encode_chunks(chunks)
        texts = [c.text for c in chunks]

        # ── 3. CoT Descriptor Generation + Encoding ──────────
        logger.info("Step 3/5: CoT descriptor generation...")
        descriptors = self.desc_gen.generate_descriptors(texts)
        desc_embs   = self.desc_gen.encode_descriptors(descriptors)
        result.descriptors = [d.__dict__ for d in descriptors]

        # ── 4. CIL Clustering ─────────────────────────────────
        logger.info("Step 4/5: CIL clustering (hybrid Leiden)...")
        labels, info = self.clustering.fit(chunk_embs, desc_embs, descriptors)
        K = info["K"]
        result.cluster_labels   = labels
        result.num_clusters     = K
        result.cluster_quality  = {
            k: v for k, v in info.items()
            if k in ("K", "argument_coherence_score", "intra_cot_similarity", "degenerate")
        }

        # Fallback nếu degenerate
        if info.get("degenerate") and self.config["pipeline"]["fallback_to_sequential"]:
            logger.warning(f"Degenerate (K={K}). Sequential fallback.")
            result.degenerate_fallback = True
            group = max(2, N // 5)
            labels = [i // group for i in range(N)]
            K = len(set(labels))
            result.cluster_labels = labels
            result.num_clusters   = K

        logger.info(
            f"  K={K} | ACS={info.get('argument_coherence_score', 0):.3f} | "
            f"IntraCoTSim={info.get('intra_cot_similarity', 0):.3f}"
        )

        # ── 5. CoT Memory-Conditioned Generation ─────────────
        logger.info("Step 5a/5: CoT memory-conditioned generation...")
        memory = CoTMemoryBank(K=K, budgets=self.cot_budgets)
        cot_chains_log: List[Dict] = []
        partials: List[str] = []
        others_all = list(range(K))

        for i, chunk in enumerate(chunks):
            k    = labels[i]
            desc = descriptors[i]
            mem  = memory.get(k)
            others = [c for c in others_all if c != k]

            logger.info(
                f"  chunk {i+1}/{N} → cluster {k} [{desc.theme}] | "
                f"mem={'yes' if not mem.is_empty() else 'empty'}"
            )

            # CoT reasoning (anchored by descriptor)
            new_cot = self.generator.generate_cot_reasoning(
                chunk.text, desc, mem, cluster_id=k, other_clusters=others)
            cot_chains_log.append({"chunk_idx": i, "cluster": k, **new_cot.to_dict()})

            # Partial summary
            partial = self.generator.generate_partial_summary(
                chunk.text, desc, mem, new_cot, cluster_id=k)
            partials.append(partial)

            # Update memory
            updated = self.generator.update_cot_memory(
                mem, new_cot, self.cot_budgets, cluster_id=k)
            memory.update(k, updated, chunk_idx=i)

        result.cot_chains         = cot_chains_log
        result.partial_summaries  = partials
        result.final_cot_memories = memory.all_chains_as_dict()

        # ── 5b. Cross-cluster CoT synthesis ──────────────────
        logger.info("Step 5b/5: Cross-cluster CoT synthesis...")
        result.summary = self.generator.generate_final_summary(
            memory.all_chains(), partials)
        result.elapsed_sec = time.time() - t0

        logger.info(
            f"Done in {result.elapsed_sec:.1f}s | "
            f"K={K} | N={N} | "
            f"ACS={result.cluster_quality.get('argument_coherence_score', 0):.3f}"
        )
        return result

    def save_result(self, result: CILResult, path: str):
        cfg = self.config["output"]
        out = {
            "summary": result.summary,
            "metadata": {
                "num_chunks":          len(result.chunks),
                "num_clusters":        result.num_clusters,
                "elapsed_sec":         round(result.elapsed_sec, 2),
                "degenerate_fallback": result.degenerate_fallback,
            },
            "cluster_labels": result.cluster_labels,
        }
        if cfg.get("save_cluster_quality"):
            out["cluster_quality"] = result.cluster_quality
        if cfg.get("save_descriptors"):
            out["descriptors"] = result.descriptors
        if cfg.get("save_cot_chains"):
            out["cot_chains"] = result.cot_chains
        if cfg.get("save_partial_summaries"):
            out["partial_summaries"] = result.partial_summaries
        if cfg.get("save_final_memories"):
            out["final_cot_memories"] = result.final_cot_memories

        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)
        logger.info(f"Saved → {path}")
