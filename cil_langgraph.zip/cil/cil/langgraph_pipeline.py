"""
langgraph_pipeline.py — CIL implemented as a LangGraph state machine.

This keeps the original CIL algorithm unchanged, but rewrites orchestration from
`CILPipeline.run()` into explicit LangGraph nodes/edges:

chunk -> embed -> descriptor -> cluster -> init_memory
      -> process_chunk -> process_chunk ... -> final_summary

The important conceptual change: CoT memory is now ordinary graph state.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, TypedDict

from langgraph.graph import END, StateGraph

from .cot_memory import CoTChain, CoTMemoryBank
from .pipeline import CILPipeline, CILResult

logger = logging.getLogger(__name__)


class CILGraphState(TypedDict, total=False):
    # Input / clock
    document: str
    t0: float

    # Stage outputs
    chunks: List[Any]
    chunk_embeddings: Any
    descriptors: List[Any]
    descriptor_embeddings: Any
    cluster_labels: List[int]
    num_clusters: int
    cluster_quality: Dict[str, Any]
    degenerate_fallback: bool

    # Stateful memory loop
    memory: Any                 # CoTMemoryBank; kept as object during graph execution
    current_idx: int
    cot_chains: List[Dict[str, Any]]
    partial_summaries: List[str]
    final_cot_memories: Dict[int, Dict[str, str]]

    # Final output
    summary: str
    elapsed_sec: float
    trace: List[str]


class CILLangGraphPipeline(CILPipeline):
    """
    LangGraph version of CILPipeline.

    Usage:
        pipeline = CILLangGraphPipeline("config.yaml")
        result = pipeline.run(document_text)

    The returned CILResult has the same shape as the original pipeline result.
    """

    def __init__(self, config_path: Optional[str] = None, **overrides):
        super().__init__(config_path=config_path, **overrides)
        self.graph = self._build_graph()

    # ───────────────────────────── graph construction ──────────────────────────
    def _build_graph(self):
        builder = StateGraph(CILGraphState)

        builder.add_node("chunk", self._chunk_node)
        builder.add_node("single_chunk", self._single_chunk_node)
        builder.add_node("embed", self._embed_node)
        builder.add_node("descriptor", self._descriptor_node)
        builder.add_node("cluster", self._cluster_node)
        builder.add_node("init_memory", self._init_memory_node)
        builder.add_node("process_chunk", self._process_chunk_node)
        builder.add_node("final", self._final_node)
        builder.add_node("empty", self._empty_node)

        builder.set_entry_point("chunk")
        builder.add_conditional_edges(
            "chunk",
            self._route_after_chunk,
            {
                "empty": "empty",
                "single": "single_chunk",
                "many": "embed",
            },
        )
        builder.add_edge("empty", END)
        builder.add_edge("single_chunk", END)

        builder.add_edge("embed", "descriptor")
        builder.add_edge("descriptor", "cluster")
        builder.add_edge("cluster", "init_memory")
        builder.add_edge("init_memory", "process_chunk")
        builder.add_conditional_edges(
            "process_chunk",
            self._route_after_process_chunk,
            {
                "continue": "process_chunk",
                "final": "final",
            },
        )
        builder.add_edge("final", END)
        return builder.compile()

    # ─────────────────────────────── node helpers ──────────────────────────────
    @staticmethod
    def _append_trace(state: CILGraphState, msg: str) -> List[str]:
        return list(state.get("trace", [])) + [msg]

    # ────────────────────────────────── nodes ─────────────────────────────────
    def _chunk_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: chunk")
        chunks = self.chunker.chunk(state["document"])
        return {
            "chunks": chunks,
            "trace": self._append_trace(state, f"chunk: {len(chunks)} chunks"),
        }

    def _empty_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.warning("LG node: empty document")
        return {
            "summary": "",
            "elapsed_sec": time.time() - state.get("t0", time.time()),
            "trace": self._append_trace(state, "empty: no chunks produced"),
        }

    def _single_chunk_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: single_chunk")
        chunk = state["chunks"][0]
        desc = self.generator.generate_descriptor(chunk.text)
        cot = self.generator.generate_cot_reasoning(
            chunk.text, desc, CoTChain(), cluster_id=0
        )
        summary = self.generator.generate_partial_summary(
            chunk.text, desc, CoTChain(), cot, cluster_id=0
        )
        return {
            "summary": summary,
            "descriptors": [desc],
            "cluster_labels": [0],
            "num_clusters": 1,
            "cot_chains": [{"chunk_idx": 0, "cluster": 0, **cot.to_dict()}],
            "partial_summaries": [summary],
            "final_cot_memories": {},
            "cluster_quality": {},
            "degenerate_fallback": False,
            "elapsed_sec": time.time() - state.get("t0", time.time()),
            "trace": self._append_trace(state, "single_chunk: summarized directly"),
        }

    def _embed_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: embed")
        chunk_embs = self.embedder.encode_chunks(state["chunks"])
        return {
            "chunk_embeddings": chunk_embs,
            "trace": self._append_trace(state, "embed: chunk sentence embeddings ready"),
        }

    def _descriptor_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: descriptor")
        texts = [c.text for c in state["chunks"]]
        descriptors = self.desc_gen.generate_descriptors(texts)
        desc_embs = self.desc_gen.encode_descriptors(descriptors)
        return {
            "descriptors": descriptors,
            "descriptor_embeddings": desc_embs,
            "trace": self._append_trace(state, "descriptor: generated and encoded"),
        }

    def _cluster_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: cluster")
        labels, info = self.clustering.fit(
            state["chunk_embeddings"],
            state["descriptor_embeddings"],
            state["descriptors"],
        )
        K = info["K"]
        degenerate_fallback = False

        if info.get("degenerate") and self.config["pipeline"].get("fallback_to_sequential", True):
            N = len(state["chunks"])
            logger.warning("Degenerate clustering; using sequential fallback")
            degenerate_fallback = True
            group = max(2, N // 5)
            labels = [i // group for i in range(N)]
            K = len(set(labels))

        cluster_quality = {
            k: v
            for k, v in info.items()
            if k in ("K", "argument_coherence_score", "intra_cot_similarity", "degenerate")
        }
        cluster_quality["K_after_fallback"] = K

        return {
            "cluster_labels": labels,
            "num_clusters": K,
            "cluster_quality": cluster_quality,
            "degenerate_fallback": degenerate_fallback,
            "trace": self._append_trace(state, f"cluster: K={K}"),
        }

    def _init_memory_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: init_memory")
        memory = CoTMemoryBank(K=state["num_clusters"], budgets=self.cot_budgets)
        return {
            "memory": memory,
            "current_idx": 0,
            "cot_chains": [],
            "partial_summaries": [],
            "trace": self._append_trace(state, "init_memory: memory bank initialized"),
        }

    def _process_chunk_node(self, state: CILGraphState) -> Dict[str, Any]:
        i = state["current_idx"]
        chunks = state["chunks"]
        labels = state["cluster_labels"]
        descriptors = state["descriptors"]
        memory: CoTMemoryBank = state["memory"]
        K = state["num_clusters"]

        chunk = chunks[i]
        k = labels[i]
        desc = descriptors[i]
        mem = memory.get(k)
        others = [c for c in range(K) if c != k]

        logger.info(
            "LG node: process_chunk %s/%s -> cluster %s [%s]",
            i + 1, len(chunks), k, getattr(desc, "theme", ""),
        )

        new_cot = self.generator.generate_cot_reasoning(
            chunk.text, desc, mem, cluster_id=k, other_clusters=others
        )
        partial = self.generator.generate_partial_summary(
            chunk.text, desc, mem, new_cot, cluster_id=k
        )
        updated = self.generator.update_cot_memory(
            mem, new_cot, self.cot_budgets, cluster_id=k
        )
        memory.update(k, updated, chunk_idx=i)

        cot_chains = list(state.get("cot_chains", []))
        cot_chains.append({"chunk_idx": i, "cluster": k, **new_cot.to_dict()})

        partials = list(state.get("partial_summaries", []))
        partials.append(partial)

        return {
            "memory": memory,
            "current_idx": i + 1,
            "cot_chains": cot_chains,
            "partial_summaries": partials,
            "trace": self._append_trace(state, f"process_chunk: {i + 1}/{len(chunks)}"),
        }

    def _final_node(self, state: CILGraphState) -> Dict[str, Any]:
        logger.info("LG node: final")
        memory: CoTMemoryBank = state["memory"]
        partials = state.get("partial_summaries", [])
        summary = self.generator.generate_final_summary(memory.all_chains(), partials)
        return {
            "summary": summary,
            "final_cot_memories": memory.all_chains_as_dict(),
            "elapsed_sec": time.time() - state.get("t0", time.time()),
            "trace": self._append_trace(state, "final: summary generated"),
        }

    # ───────────────────────────── conditional edges ───────────────────────────
    @staticmethod
    def _route_after_chunk(state: CILGraphState) -> str:
        n = len(state.get("chunks", []))
        if n == 0:
            return "empty"
        if n == 1:
            return "single"
        return "many"

    @staticmethod
    def _route_after_process_chunk(state: CILGraphState) -> str:
        return "continue" if state["current_idx"] < len(state["chunks"]) else "final"

    # ───────────────────────────────── public API ─────────────────────────────
    def run(self, document: str) -> CILResult:
        t0 = time.time()
        final_state = self.graph.invoke(
            {
                "document": document,
                "t0": t0,
                "trace": [],
                "summary": "",
            }
        )
        result = self._state_to_result(final_state)
        logger.info(
            "LangGraph CIL done in %.1fs | K=%s | N=%s",
            result.elapsed_sec, result.num_clusters, len(result.chunks),
        )
        return result

    def _state_to_result(self, state: CILGraphState) -> CILResult:
        descriptors = []
        for d in state.get("descriptors", []):
            descriptors.append(d.__dict__ if hasattr(d, "__dict__") else d)

        return CILResult(
            summary=state.get("summary", ""),
            chunks=state.get("chunks", []),
            cluster_labels=state.get("cluster_labels", []),
            num_clusters=state.get("num_clusters", 0),
            descriptors=descriptors,
            cot_chains=state.get("cot_chains", []),
            partial_summaries=state.get("partial_summaries", []),
            final_cot_memories=state.get("final_cot_memories", {}),
            cluster_quality=state.get("cluster_quality", {}),
            elapsed_sec=state.get("elapsed_sec", 0.0),
            degenerate_fallback=state.get("degenerate_fallback", False),
        )

    def graph_mermaid(self) -> str:
        """Return a Mermaid diagram if current LangGraph version supports it."""
        try:
            return self.graph.get_graph().draw_mermaid()
        except Exception:
            return """graph TD
    chunk -->|empty| empty
    chunk -->|single| single_chunk
    chunk -->|many| embed
    embed --> descriptor
    descriptor --> cluster
    cluster --> init_memory
    init_memory --> process_chunk
    process_chunk -->|continue| process_chunk
    process_chunk -->|final| final
"""
