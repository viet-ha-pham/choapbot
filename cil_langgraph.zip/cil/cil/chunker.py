"""chunker.py — Chia document thành chunks theo sentence boundary."""
import re, logging
from dataclasses import dataclass
from typing import List

logger = logging.getLogger(__name__)

@dataclass
class Chunk:
    idx: int; text: str; start_char: int; end_char: int; token_count: int

class Chunker:
    def __init__(self, chunk_size=512, overlap=50, min_chunk_size=100):
        self.chunk_size = chunk_size; self.overlap = overlap; self.min_chunk_size = min_chunk_size

    @staticmethod
    def _tok(t): return int(len(t.split()) * 1.33)

    @staticmethod
    def _sents(text): return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text.strip()) if s.strip()]

    def chunk(self, document: str) -> List[Chunk]:
        sents = self._sents(document)
        if not sents: return []
        chunks, cur, cur_tok, offset = [], [], 0, 0
        for sent in sents:
            st = self._tok(sent)
            if cur_tok + st > self.chunk_size and cur:
                txt = " ".join(cur)
                if self._tok(txt) >= self.min_chunk_size:
                    s = document.find(cur[0], offset)
                    chunks.append(Chunk(len(chunks), txt, max(0,s), max(0,s)+len(txt), self._tok(txt)))
                    offset = max(0, s)
                ov, ovt = [], 0
                for x in reversed(cur):
                    t = self._tok(x)
                    if ovt + t <= self.overlap: ov.insert(0, x); ovt += t
                    else: break
                cur, cur_tok = ov + [sent], ovt + st
            else:
                cur.append(sent); cur_tok += st
        if cur:
            txt = " ".join(cur)
            if self._tok(txt) >= self.min_chunk_size:
                s = document.find(cur[0], offset)
                chunks.append(Chunk(len(chunks), txt, max(0,s), max(0,s)+len(txt), self._tok(txt)))
        logger.info(f"Chunked → {len(chunks)} chunks")
        return chunks
