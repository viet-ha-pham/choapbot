"""
cot_descriptor.py
CoT Descriptor — core novelty của CIL Stage 1.

Mỗi chunk nhận một lightweight CoT descriptor trước khi clustering:
  Claim:     Luận điểm chính (≤24 tokens)
  Theme:     Vai trò discourse (≤16 tokens, vd: "methodology", "results")
  KeyTerms:  3-5 domain anchor terms (≤24 tokens)

Descriptor được encode bằng SBERT → embedding t_i
→ dùng trong hybrid edge weighting cho Leiden graph.

Khác với CoTChain (4 fields, dùng trong memory):
  - Descriptor: 3 fields, ≤64 tokens, TRƯỚC clustering
  - CoTChain:   4 fields, ≤256 tokens, SAU clustering (memory accumulation)
"""

import logging
import re
from dataclasses import dataclass
from typing import List, Optional
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class CoTDescriptor:
    """
    Lightweight CoT descriptor cho một chunk.
    Dùng để inform Leiden clustering — KHÔNG dùng trong memory.
    """
    claim:     str = ""   # ≤24 tokens: main assertion
    theme:     str = ""   # ≤16 tokens: discourse function
    key_terms: str = ""   # ≤24 tokens: domain anchor terms

    def is_empty(self) -> bool:
        return not any([self.claim, self.theme, self.key_terms])

    def to_string(self) -> str:
        """Format để encode bằng SBERT."""
        parts = []
        if self.claim:     parts.append(f"Claim: {self.claim}")
        if self.theme:     parts.append(f"Theme: {self.theme}")
        if self.key_terms: parts.append(f"Key Terms: {self.key_terms}")
        return " | ".join(parts) if parts else ""

    def to_prompt_str(self) -> str:
        """Format dễ đọc cho LLM judge prompt."""
        return (
            f"Claim: {self.claim}\n"
            f"Theme: {self.theme}\n"
            f"Key Terms: {self.key_terms}"
        )

    @classmethod
    def from_llm_output(cls, text: str) -> "CoTDescriptor":
        """Parse LLM output thành CoTDescriptor."""
        desc = cls()
        field_map = {
            "claim":      "claim",
            "theme":      "theme",
            "key terms":  "key_terms",
            "key_terms":  "key_terms",
            "keyterms":   "key_terms",
            "keywords":   "key_terms",
        }
        current_field, current_lines = None, []

        for line in text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            matched = False
            for prefix, attr in field_map.items():
                if line.lower().startswith(prefix + ":"):
                    if current_field:
                        setattr(desc, current_field, " ".join(current_lines).strip())
                    current_field = attr
                    current_lines = [line[len(prefix)+1:].strip()]
                    matched = True
                    break
            if not matched and current_field:
                current_lines.append(line)

        if current_field and current_lines:
            setattr(desc, current_field, " ".join(current_lines).strip())

        # Fallback
        if desc.is_empty() and text.strip():
            desc.claim = text.strip()[:200]
            desc.theme = "unknown"

        return desc


class CoTDescriptorGenerator:
    """
    Generate CoT descriptors cho tất cả chunks — 1 LLM call per chunk.
    Encode descriptors bằng SBERT cho hybrid edge weighting.
    """

    PROMPT_TEMPLATE = """[CHUNK]
{chunk_text}

[INSTRUCTION]
Characterize this chunk in structured form for thematic clustering.

Claim: The main assertion or contribution in ONE sentence (≤24 tokens).
Theme: The discourse function in 2-4 words. Choose from or adapt:
  "motivation", "methodology", "experimental setup", "results",
  "analysis", "limitations", "related work", "background", "conclusion"
Key Terms: 3-5 domain-specific anchor terms, comma-separated.

Output EXACTLY in this format (no extra text):
Claim: <your claim>
Theme: <your theme>
Key Terms: <term1>, <term2>, <term3>"""

    def __init__(self, llm_generator, sbert_model):
        """
        Args:
            llm_generator: LLMGenerator instance
            sbert_model:   SentenceTransformer instance (reuse từ embedder)
        """
        self.llm = llm_generator
        self.sbert = sbert_model

    def generate_descriptors(
        self,
        chunk_texts: List[str],
        max_tokens: int = 80,
    ) -> List[CoTDescriptor]:
        """
        Generate descriptor cho mỗi chunk.
        Returns List[CoTDescriptor] với len = len(chunk_texts).
        """
        descriptors = []
        N = len(chunk_texts)
        logger.info(f"Generating CoT descriptors for {N} chunks...")

        for i, text in enumerate(chunk_texts):
            prompt = self.PROMPT_TEMPLATE.format(chunk_text=text[:800])
            raw = self.llm._call(prompt, max_tokens=max_tokens,
                                  system="You characterize document chunks for thematic clustering.")
            desc = CoTDescriptor.from_llm_output(raw)
            descriptors.append(desc)
            logger.debug(f"  chunk {i+1}/{N}: theme='{desc.theme}' claim='{desc.claim[:50]}...'")

        logger.info(f"Generated {len(descriptors)} CoT descriptors")
        return descriptors

    def encode_descriptors(
        self,
        descriptors: List[CoTDescriptor],
    ) -> np.ndarray:
        """
        Encode descriptors thành ma trận embedding (N, d).
        Dùng SBERT encode descriptor.to_string().
        """
        texts = [d.to_string() if not d.is_empty() else "unknown chunk" for d in descriptors]
        logger.info(f"Encoding {len(texts)} CoT descriptors with SBERT...")
        embs = self.sbert.encode(
            texts,
            normalize_embeddings=True,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        logger.info(f"Descriptor embeddings: shape={embs.shape}")
        return embs   # (N, d)
