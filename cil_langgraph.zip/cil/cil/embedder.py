"""embedder.py — Sentence embedding với SBERT."""
import re, logging
import numpy as np
from typing import List
from sentence_transformers import SentenceTransformer
from .chunker import Chunk

logger = logging.getLogger(__name__)

class SentenceEmbedder:
    def __init__(self, model_name="all-mpnet-base-v2", device="cpu", batch_size=64, normalize=True):
        logger.info(f"Loading {model_name} on {device}")
        self.model = SentenceTransformer(model_name, device=device)
        self.batch_size = batch_size; self.normalize = normalize

    def encode_chunks(self, chunks: List[Chunk]) -> List[np.ndarray]:
        all_sents, bounds = [], []
        for c in chunks:
            sents = [s.strip() for s in re.split(r'(?<=[.!?])\s+', c.text) if len(s.strip()) > 10]
            if not sents: sents = [c.text[:300]]
            s = len(all_sents); all_sents.extend(sents); bounds.append((s, len(all_sents)))
        embs = self.model.encode(all_sents, batch_size=self.batch_size,
                                  normalize_embeddings=self.normalize,
                                  show_progress_bar=len(all_sents)>100,
                                  convert_to_numpy=True)
        logger.info(f"Encoded {len(all_sents)} sentences, dim={embs.shape[1]}")
        return [embs[s:e] for s, e in bounds]
