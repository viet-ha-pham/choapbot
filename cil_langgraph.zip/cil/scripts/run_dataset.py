"""
run_dataset.py — Batch trên arXiv/PubMed.

Ví dụ:
    python scripts/run_dataset.py --dataset arxiv --split test --num-samples 100
    python scripts/run_dataset.py --dataset pubmed --split test --resume
    python scripts/run_dataset.py --dataset arxiv --split test --gamma 0  # ablation: no judge
"""
import argparse, json, logging, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from cil import CILPipeline

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset",     choices=["arxiv","pubmed"], default="arxiv")
    p.add_argument("--split",       choices=["train","validation","test"], default="test")
    p.add_argument("--num-samples", type=int, default=None)
    p.add_argument("--output-dir",  default=None)
    p.add_argument("--config",      default="config.yaml")
    p.add_argument("--base-url",    default="http://localhost:8000/v1")
    p.add_argument("--model",       default="Qwen3-8B")
    p.add_argument("--device",      default="cuda")
    p.add_argument("--alpha",       type=float, default=None)
    p.add_argument("--beta",        type=float, default=None)
    p.add_argument("--gamma",       type=float, default=None)
    p.add_argument("--top-k",       type=int, default=None)
    p.add_argument("--resume",      action="store_true")
    p.add_argument("--verbose",     action="store_true")
    args = p.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

    try:
        from datasets import load_dataset
    except ImportError:
        print("[ERROR] pip install datasets"); sys.exit(1)

    cfg_name = "arxiv" if args.dataset == "arxiv" else "pubmed"
    print(f"[INFO] Loading scientific_papers/{cfg_name} {args.split}...")
    ds = load_dataset("scientific_papers", cfg_name,
                      split=args.split, trust_remote_code=True)
    if args.num_samples:
        ds = ds.select(range(min(args.num_samples, len(ds))))
    print(f"[INFO] {len(ds)} samples")

    out_dir = Path(args.output_dir or f"outputs/{args.dataset}_{args.split}")
    out_dir.mkdir(parents=True, exist_ok=True)

    overrides = {k: v for k, v in {
        "base_url": args.base_url, "model": args.model, "device": args.device,
        "alpha": args.alpha, "beta": args.beta, "gamma": args.gamma,
        "top_k_judge": args.top_k,
    }.items() if v is not None}

    cfg = args.config if Path(args.config).exists() else None
    pipeline = CILPipeline(config_path=cfg, **overrides)

    success, errors = [], []
    for idx, sample in enumerate(ds):
        sid = f"{args.dataset}_{args.split}_{idx:05d}"
        out_path = out_dir / f"{sid}.json"
        if args.resume and out_path.exists():
            print(f"[{idx+1}/{len(ds)}] Skip {sid}"); continue

        article   = sample.get("article", "")
        reference = sample.get("abstract", "")
        if not article or len(article.split()) < 100:
            print(f"[{idx+1}] Skip {sid}: too short"); continue

        print(f"[{idx+1}/{len(ds)}] {sid} ({len(article.split())} words)")
        try:
            t0 = time.time()
            result = pipeline.run(article)
            elapsed = time.time() - t0
            record = {
                "id": sid, "summary": result.summary,
                "reference": reference,
                "article_words": len(article.split()),
                "metadata": {
                    "num_chunks": len(result.chunks),
                    "num_clusters": result.num_clusters,
                    "elapsed_sec": round(elapsed, 2),
                    "degenerate_fallback": result.degenerate_fallback,
                },
                "cluster_quality":    result.cluster_quality,
                "cluster_labels":     result.cluster_labels,
                "descriptors":        result.descriptors,
                "cot_chains":         result.cot_chains,
                "partial_summaries":  result.partial_summaries,
                "final_cot_memories": result.final_cot_memories,
            }
            out_path.write_text(json.dumps(record, ensure_ascii=False, indent=2))
            success.append({
                "id": sid, "elapsed": elapsed,
                "K": result.num_clusters,
                "acs": result.cluster_quality.get("argument_coherence_score", 0),
            })
            print(f"  → K={result.num_clusters} | ACS={success[-1]['acs']:.3f} | {elapsed:.1f}s")
        except Exception as e:
            logging.error(f"ERROR {sid}: {e}")
            errors.append({"id": sid, "error": str(e)})

    log = {
        "dataset": args.dataset, "split": args.split,
        "total": len(ds), "success": len(success), "errors": len(errors),
        "avg_acs": sum(r["acs"] for r in success) / max(1, len(success)),
        "results": success, "errors_detail": errors,
    }
    (out_dir / "run_log.json").write_text(json.dumps(log, indent=2))
    print(f"\n[INFO] Done: {len(success)} success | avg ACS={log['avg_acs']:.3f}")
    print(f"[INFO] Evaluate: python scripts/evaluate.py --pred-dir {out_dir}")

if __name__ == "__main__":
    main()
