"""
run_single_langgraph.py — Tóm tắt 1 document bằng CIL LangGraph.

Ví dụ:
    python scripts/run_single_langgraph.py --input data/samples/paper.txt
    python scripts/run_single_langgraph.py --input paper.txt --gamma 0 --top-k 0
    python scripts/run_single_langgraph.py --input paper.txt --save-graph outputs/cil_graph.mmd
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from cil import CILLangGraphPipeline


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output", default=None)
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--base-url", default=None)
    p.add_argument("--model", default=None)
    p.add_argument("--device", default=None)
    p.add_argument("--alpha", type=float, default=None, help="embedding weight")
    p.add_argument("--beta", type=float, default=None, help="CoT descriptor weight")
    p.add_argument("--gamma", type=float, default=None, help="LLM judge weight")
    p.add_argument("--top-k", type=int, default=None, help="LLM judge top-K pairs")
    p.add_argument("--save-graph", default=None, help="Save LangGraph Mermaid diagram to .mmd")
    p.add_argument("--verbose", action="store_true")
    args = p.parse_args()

    path = Path(args.input)
    if not path.exists():
        print(f"[ERROR] Not found: {path}")
        sys.exit(1)

    document = path.read_text(encoding="utf-8")
    print(f"[INFO] Input: {path.name} | {len(document.split())} words")

    overrides = {}
    if args.base_url:
        overrides["base_url"] = args.base_url
    if args.model:
        overrides["model"] = args.model
    if args.device:
        overrides["device"] = args.device
    if args.alpha is not None:
        overrides["alpha"] = args.alpha
    if args.beta is not None:
        overrides["beta"] = args.beta
    if args.gamma is not None:
        overrides["gamma"] = args.gamma
    if args.top_k is not None:
        overrides["top_k_judge"] = args.top_k
    if args.verbose:
        overrides["log_level"] = "DEBUG"

    cfg = args.config if Path(args.config).exists() else None
    pipeline = CILLangGraphPipeline(config_path=cfg, **overrides)

    if args.save_graph:
        graph_path = Path(args.save_graph)
        graph_path.parent.mkdir(parents=True, exist_ok=True)
        graph_path.write_text(pipeline.graph_mermaid(), encoding="utf-8")
        print(f"[INFO] Saved graph diagram → {graph_path}")

    print("[INFO] Running CIL LangGraph pipeline...")
    result = pipeline.run(document)

    print("\n" + "=" * 60)
    print("FINAL SUMMARY")
    print("=" * 60)
    print(result.summary)
    print("=" * 60)
    print(
        f"K={result.num_clusters} clusters | N={len(result.chunks)} chunks | "
        f"Time={result.elapsed_sec:.1f}s"
    )
    print(
        f"ACS={result.cluster_quality.get('argument_coherence_score', 0):.3f} | "
        f"IntraCoTSim={result.cluster_quality.get('intra_cot_similarity', 0):.3f}"
    )

    output = args.output or f"outputs/{path.stem}_cil_langgraph.json"
    pipeline.save_result(result, output)
    print(f"\n[INFO] Saved → {output}")


if __name__ == "__main__":
    main()
