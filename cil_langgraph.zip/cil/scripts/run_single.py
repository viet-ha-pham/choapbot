"""
run_single.py — Tóm tắt 1 document với CIL.

Ví dụ:
    python scripts/run_single.py --input data/samples/paper.txt
    python scripts/run_single.py --input paper.txt --device cuda --alpha 0.4 --beta 0.4 --gamma 0.2
    python scripts/run_single.py --input paper.txt --gamma 0   # tắt LLM judge
"""
import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from cil import CILPipeline

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input",    required=True)
    p.add_argument("--output",   default=None)
    p.add_argument("--config",   default="config.yaml")
    p.add_argument("--base-url", default=None)
    p.add_argument("--model",    default=None)
    p.add_argument("--device",   default=None)
    p.add_argument("--alpha",    type=float, default=None, help="emb weight")
    p.add_argument("--beta",     type=float, default=None, help="CoT desc weight")
    p.add_argument("--gamma",    type=float, default=None, help="LLM judge weight")
    p.add_argument("--top-k",    type=int,   default=None, help="LLM judge top-K pairs")
    p.add_argument("--verbose",  action="store_true")
    args = p.parse_args()

    path = Path(args.input)
    if not path.exists(): print(f"[ERROR] Not found: {path}"); sys.exit(1)
    document = path.read_text(encoding="utf-8")
    print(f"[INFO] Input: {path.name} | {len(document.split())} words")

    overrides = {}
    if args.base_url: overrides["base_url"] = args.base_url
    if args.model:    overrides["model"]    = args.model
    if args.device:   overrides["device"]   = args.device
    if args.alpha  is not None: overrides["alpha"]     = args.alpha
    if args.beta   is not None: overrides["beta"]      = args.beta
    if args.gamma  is not None: overrides["gamma"]     = args.gamma
    if args.top_k  is not None: overrides["top_k_judge"] = args.top_k
    if args.verbose: overrides["log_level"] = "DEBUG"

    cfg = args.config if Path(args.config).exists() else None
    pipeline = CILPipeline(config_path=cfg, **overrides)

    print("[INFO] Running CIL pipeline...")
    result = pipeline.run(document)

    print("\n" + "="*60)
    print("FINAL SUMMARY")
    print("="*60)
    print(result.summary)
    print("="*60)
    print(f"K={result.num_clusters} clusters | N={len(result.chunks)} chunks | "
          f"Time={result.elapsed_sec:.1f}s")
    print(f"ACS={result.cluster_quality.get('argument_coherence_score',0):.3f} | "
          f"IntraCoTSim={result.cluster_quality.get('intra_cot_similarity',0):.3f}")

    # In descriptors
    print("\n[CoT Descriptors per chunk]")
    for i, d in enumerate(result.descriptors[:5]):
        print(f"  chunk {i+1}: theme='{d.get('theme','')}' | claim='{d.get('claim','')[:50]}...'")
    if len(result.descriptors) > 5:
        print(f"  ... ({len(result.descriptors)-5} more)")

    output = args.output or f"outputs/{path.stem}_cil.json"
    pipeline.save_result(result, output)
    print(f"\n[INFO] Saved → {output}")

if __name__ == "__main__":
    main()
