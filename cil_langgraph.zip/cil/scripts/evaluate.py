"""
evaluate.py — ROUGE, BERTScore, AlignScore + ACS cluster quality.

Ví dụ:
    python scripts/evaluate.py --pred-dir outputs/arxiv_test/
    python scripts/evaluate.py --pred-dir outputs/arxiv_test/ --metrics rouge bertscore cot acs
"""
import argparse, json, sys
from pathlib import Path
from typing import List, Dict
import numpy as np


def load_results(d: Path) -> List[Dict]:
    files = sorted(f for f in d.glob("*.json") if f.name != "run_log.json")
    out = []
    for f in files:
        rec = json.loads(f.read_text())
        if "summary" in rec and "reference" in rec:
            out.append(rec)
    return out


def rouge(preds, refs):
    from rouge_score import rouge_scorer
    sc = rouge_scorer.RougeScorer(["rouge1","rouge2","rougeL"], use_stemmer=True)
    r1,r2,rl=[],[],[]
    for p,r in zip(preds,refs):
        s=sc.score(r,p); r1.append(s["rouge1"].fmeasure); r2.append(s["rouge2"].fmeasure); rl.append(s["rougeL"].fmeasure)
    return {"ROUGE-1":np.mean(r1)*100,"ROUGE-2":np.mean(r2)*100,"ROUGE-L":np.mean(rl)*100}


def bertscore(preds, refs):
    try:
        from bert_score import score as bsc
        _,_,F=bsc(preds,refs,lang="en",verbose=False)
        return {"BERTScore-F1":F.mean().item()*100}
    except ImportError:
        print("[WARN] pip install bert-score"); return {}


def alignscore(preds, sources):
    try:
        from alignscore import AlignScore
        sc=AlignScore(model="roberta-large",batch_size=8,device="cuda",alignment_type="NLI_STS")
        return {"AlignScore":np.mean(sc.score(contexts=sources,claims=preds))*100}
    except ImportError:
        print("[WARN] pip install git+https://github.com/yuh-zha/AlignScore"); return {}


def cot_quality(data: List[Dict]):
    import re
    has_num = re.compile(r'\d+\.?\d*\s*(%|BLEU|F1|accuracy|score|points?)')
    spec, cov, cl = [], [], []
    for d in data:
        for chain in d.get("cot_chains", []):
            claim = chain.get("claim",""); ev=chain.get("evidence","")
            impl = chain.get("implication",""); cross=chain.get("cross_link","")
            spec.append(1.0 if bool(has_num.search(claim)) or len(claim.split())>8 else 0.0)
            cov.append(sum([bool(claim),bool(ev),bool(impl),bool(cross)])/4.0)
            cl.append(1.0 if cross else 0.0)
    if not spec: return {}
    return {"CoT Claim Specificity":np.mean(spec)*100,
            "CoT Field Coverage":np.mean(cov)*100,
            "CoT Cross-link Rate":np.mean(cl)*100}


def acs_metrics(data: List[Dict]):
    """Argument Coherence Score từ kết quả CIL."""
    acs_vals = [d.get("cluster_quality",{}).get("argument_coherence_score",None)
                for d in data]
    acs_vals = [v for v in acs_vals if v is not None]
    intra_vals = [d.get("cluster_quality",{}).get("intra_cot_similarity",None)
                  for d in data]
    intra_vals = [v for v in intra_vals if v is not None]
    out = {}
    if acs_vals:   out["Argument Coherence Score (ACS)"] = np.mean(acs_vals)*100
    if intra_vals: out["Intra-cluster CoT Sim"]          = np.mean(intra_vals)*100
    # Descriptor theme diversity
    themes = []
    for d in data:
        for desc in d.get("descriptors", []):
            t = desc.get("theme","")
            if t: themes.append(t.lower().strip())
    if themes:
        from collections import Counter
        cnt = Counter(themes)
        out["Top-3 Themes"] = str(dict(cnt.most_common(3)))
    return out


def by_length(data, preds, refs):
    from rouge_score import rouge_scorer
    sc = rouge_scorer.RougeScorer(["rouge1"], use_stemmer=True)
    bins = [("2K-4K",2000,4000),("4K-8K",4000,8000),("8K-16K",8000,16000),(">16K",16000,10**9)]
    print(f"\n  {'Bin':<12}{'N':>6}{'R-1':>8}{'ACS':>8}")
    print("  " + "-"*36)
    for label,lo,hi in bins:
        idx=[i for i,d in enumerate(data)
             if lo<=d.get("article_words",d.get("metadata",{}).get("article_words",0))<hi]
        if not idx: continue
        r1s=[sc.score(refs[i],preds[i])["rouge1"].fmeasure*100 for i in idx]
        acs_=[data[i].get("cluster_quality",{}).get("argument_coherence_score",0)*100 for i in idx]
        print(f"  {label:<12}{len(idx):>6}{np.mean(r1s):>8.2f}{np.mean(acs_):>8.2f}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--pred-dir", required=True)
    p.add_argument("--metrics", nargs="+",
                   choices=["rouge","bertscore","alignscore","cot","acs"],
                   default=["rouge","bertscore","cot","acs"])
    p.add_argument("--output", default=None)
    args = p.parse_args()

    pred_dir = Path(args.pred_dir)
    data = load_results(pred_dir)
    if not data: print(f"[ERROR] No results in {pred_dir}"); sys.exit(1)
    print(f"[INFO] {len(data)} samples")

    preds = [d["summary"]   for d in data]
    refs  = [d["reference"] for d in data]
    all_m = {}

    if "rouge"      in args.metrics: all_m.update(rouge(preds, refs))
    if "bertscore"  in args.metrics: all_m.update(bertscore(preds, refs))
    if "alignscore" in args.metrics:
        srcs = [d.get("article","") for d in data]
        if any(srcs): all_m.update(alignscore(preds, srcs))
    if "cot"        in args.metrics: all_m.update(cot_quality(data))
    if "acs"        in args.metrics: all_m.update(acs_metrics(data))

    # In bảng kết quả
    print(f"\n{'='*55}")
    print(f"  CIL Results — {pred_dir.name}")
    print(f"{'='*55}")
    for k, v in all_m.items():
        if isinstance(v, float): print(f"  {k:<35} {v:.2f}")
        else: print(f"  {k:<35} {v}")
    print(f"{'='*55}")

    if "rouge" in args.metrics: by_length(data, preds, refs)

    if args.output:
        serializable = {k: v for k, v in all_m.items() if isinstance(v, (int, float))}
        Path(args.output).write_text(json.dumps(serializable, indent=2))
        print(f"\n[INFO] Saved → {args.output}")

if __name__ == "__main__":
    main()
